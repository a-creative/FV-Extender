function Account() {
    this.table = 'account';
    this.attrs = {        
        "id" : "TEXT PRIMARY KEY",
        "name" : "TEXT",
        "image" : "TEXT",
        "updated" : "INTEGER",
        "sound" : "INTEGER DEFAULT 1",
        "return_gift_text" : "TEXT",
        "speed" : "INTEGER DEFAULT 2"
    };    
}

Account.prototype = new DB_object();

function request_user_info_from_FB( callback ) {
    jQuery.get( 'http://www.facebook.com/', function( html ) {
        
        // Find user id in output from ajax call
        var matches = html.match( /Env=\{user:(\d+),/ );        
        if ( matches ) {
            
            // If user was found
            // ( We are already logged in )
            
            var login = {};
            
            // Check if we've just logged in
            login.just_logged_in = ( current_user_id === -1 );
            login.user_changed = ( matches[ 1 ] && ( current_user_id !== matches[ 1 ] ) );
            
            
            // Save user id in memory
            current_user_id = matches[ 1 ];
            
            
            // Open user database(initialize if necesary)
            current_user_db = new DB( current_user_id );
            current_user_db.init(function() {
                                
                // When user database is initialized
			
				// Update account information
				var welcome_pagelet_re = /<script>big_pipe.onPageletArrive\(({"phase":1,"id":"pagelet_welcome_box",.+?)\);<\/script>/; 
				
				var matches = html.match( welcome_pagelet_re );
				if ( matches.length ) {
					var account = new Account();
					account.id = current_user_id;
					
					var js_obj = eval('(' + matches[ 1 ] + ')');
					
					var DOM_el = $( js_obj.content.pagelet_welcome_box );
					
					var img_el = DOM_el.find('.fbxWelcomeBoxBlock img');
					if ( img_el.length ) {
						account.image = img_el.attr('src' )
					}
					
					var name_el = DOM_el.find('.fbxWelcomeBoxName');
					if ( name_el.length ) {
						account.name = name_el.html()
					}
					
					current_user_db.updateAccount( account );
                    
                    login.account = account;
                } else {
                    
                    // Make sure we return something valid if FB check fails
                    login.account = { id : current_user_id, name: "UNKNOWN" };
                }

                callback( login );
            } );
        } else {
            
            // If no user was found
            // ( We are not logged in yet )
            
            callback( false );
        }
    } );    
}

Account.prototype.getLoginFromFB = function ( live_user_id, callback ) {

    // Check value of live user id
    if ( live_user_id === -1 ) {
        
        // It has not been set yet
        log_info( "Not able to detect user. Tries getting from Facebook" );
        
        // Update or create user with info from facebook.com
        request_user_info_from_FB( callback );
        
        
    } else if ( live_user_id === false ) {
        
        // User id was tried grabbed from Facebook but NOT found
        log_info( "User id could not be found from FB" ); 
         
        // Check if there is recorded a current user in bgp
        if ( current_user_id !== -1 ) {
          
            // Current user was recorded - This user is now logged out
            log_info( "Current user was recorded. Logging this out" );
            
            // Reset login data
            callback( false )
                        
        }          
        
    } else {
        
        // User id was  grabbed from Facebook and found
        
        // Check if there is recorded a current user in bgp
        if ( current_user_id != -1 ) {
            
            // A current user is recorded
            
            // Check if user has changed
            if ( current_user_id == live_user_id ) {
                
                // User is still the same
                
                // Do nothing
                
            } else {
                log_info( "User id was fround from FB:" +  live_user_id ); 
                log_info( "A recorded user was also found:" +  current_user_id ); 
                
                // User has changed
                
                // Update or create user with info from facebook.com
                log_info( "User id found was different recorded user. Getting user from FB." ); 
                request_user_info_from_FB( callback );
                
            }            
            
        } else {
            
            // A current user is not recorded - User has logged in
            
            // Update or create user with info from facebook.com
            log_info( "A recorded user was not found. User is logged in. Getting user from FB." ); 
            request_user_info_from_FB( callback );
         
        }
    }
}
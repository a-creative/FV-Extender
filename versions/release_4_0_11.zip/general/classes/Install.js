function Install() {
    this.table = 'install';    
    this.attrs = {        
        "id" : "INTEGER DEFAULT 1",
        "last_info_update" : "INTEGER DEFAULT 0"
    };    
}

Install.prototype.load = function( callback ) {
    this.id = 1;
    master_db.loadObject( this, this.table, callback );   
}

Install.prototype.save = function( callback ) {
	
    this.id = 1;
    master_db.insertObjects( [ this ], 0, this.table, callback);
}
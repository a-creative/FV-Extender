function Request() {
    this.table = 'requests';    
    
    this.attrs = {
        "id" : "TEXT PRIMARY KEY",
        "app_id" : "INTEGER",
        "app_name" : "TEXT",
        "app_image" : "TEXT",
        "app_link" : "TEXT",
        "item_id"   : "TEXT",
        "item_name" : "TEXT",
        "item_image_url" : "TEXT",
        "text" : "TEXT",
        "user_text" : "TEXT",
        "ajax_init_script" : "TEXT",
        "ajax_init_data" : "TEXT",
        "ajax_init_data_accept_part" : "TEXT",
        "ajax_init_data_reject_part" : "TEXT",
        
        "state" : "INTEGER DEFAULT 0",
        // 0 = Ready: When downloaded and created
        // 3 = Done: When processing is done        
        // 5+= Error codes: See posible error text in "state_text"
        // UDELADT: 4 = Approved: When processing is done and user has aknowledged this
        // UDELADT: 1 = Queued: When queued for processing with "action"
        // UDELADT: 2 = Running: When being processed
        
        "action" : "TEXT", // Reject / Accept
        "state_text" : "TEXT",
        "added_time" : "INTEGER",
        
        // neighbor
        "neighbor_id" : "INTEGER",
        "neighbor_name" : "TEXT",
        "neighbor_image" : "TEXT",
        "updated" : "INTEGER"
    };    
}

Request.prototype = new DB_object();

Request.prototype.getItemImageUrl = function() {
    
    var app_def = app_defs[ this.app_id ];
    
    var url;
    
    if ( app_def && (!this.item_name ) ) {
        
        // This is a request for help
        url = "../css/img/help_request.png";
            
    } else if ( this.item_image_url ) {
        
        // If an image has been grabbed and saved
        url = this.item_image_url;        
    } else if (
            app_def
        &&  app_def.items
        && app_def.items.common
        && app_def.items.common[ this.item_id ]
        && this.item_name
    ) {
        // This is a common gift
        url = "/games/" + app_def.name + "/img/items/common/" + this.item_id + ".png";
    } else {
        
        // else use the default image
        url = "../css/img/gift.png";   
    }
    
    return url;
};

Request.prototype.getReadyOrderedByItemIdFromAppId = function( app_id, callback ) {
    current_user_db.getReadyRequestsOrderedByItemFromAppId( app_id, callback );
};

Request.prototype.getDefaultAction = function( callback ) {
    current_user_db.getDefaultActionForRequest( this, callback );
}

function _requestAppUrlStep2( request, URI2, callback ) {
    $.ajax( {
        type: "GET",
        url: URI2,
        timeout: 10000,
        dataType: 'text',
        success: function( data, textStatus, XMLHttpRequest ) {
            _procesAppResultPage( request, data, textStatus, XMLHttpRequest, URI2, callback );
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {                    
            
            // Mark request as failed
            request.state = 5;
            request.state_text = 'Connection error(1):' + textStatus;
            
            // Save updated state and callback
            request.save( callback );
            
        }
    } );       
}

function _procesAppResultPage( request, data, textStatus, XMLHttpRequest, app_url, callback ) {
    var app_def = app_defs[ request.app_id ];
    if ( app_def ) {
        
        // If app definition
        
        // Process the result page
        
        app_defs[ request.app_id ].functions.processResultPage( request, data, textStatus, XMLHttpRequest, app_url, callback );
    } else {
        
        // If no app definition: Don't care about the result page
        
        // Mark request as done
        request.state = 3;
        
        // Save updated state and callback
        request.save( callback );
    }   
}

function _checkForHang( tab_id, request, app_url, tries ) {
    
    setTimeout( function() {
    
        console.log('Checking for break downn on url:' + app_url )
    
        // Get updated information about the request state
        request.load( function( request ) {
            
            // If request is still running
            if ( request.state == 0 ) {
                console.log('Breakdown on url:' + app_url )
                
                // If the request is not done
                
                if ( tries == 0 ) {
                    
                    console.log('check for hang 1st:' + app_url);
                    chrome.tabs.executeScript( parseInt( tab_id ), { allFrames: true, code: "if ( FVE_app_def && FVE_app_def.functions && FVE_app_def.functions.checkForHang ) { FVE_app_def.functions.checkForHang() };" }, function () {
                        
                        console.log('check for hang 1st returned:' + app_url);
                        
                        tries++;
                        _checkForHang( tab_id, request, app_url, tries );             
                    } )
                        
                } else {
                
                    console.log('check for hang 2nd:' + app_url);
                    
                    // Reload the tab
                    chrome.tabs.update(
                        parseInt( tab_id ),
                        { url: app_url, selected : false },
                        function() {
                            console.log('check for hang 2nd returned:' + app_url);
                            
                            tries++;
                            _checkForHang( tab_id, request, app_url, tries );                     
                        }
                    );
                }
            } else {
             
                // Request is done and we don't need to check anymore
                console.log('Break down check done for url:' + app_url );
            }
        } );
        
    }, 15000 )
}

function _requestAppUrl( proces_in_tab_id, request, is_help_request, URI, step2, callback ) {
    
    // Check if this is going to be accepted visually or silently
    if ( proces_in_tab_id ) {
        
        // Accept visually in a tab
        
        // Reserve the tab for this request
        
        // Check is app is defined
        if ( app_defs[ request.app_id ] ) {
            
            // Load return gift message
            current_login.account.load( function( account ) {
                
                // If so make sure the tab knows the definition so it can finish
                // the processing at the right time and return a gift.
                // And make sure this tab is reserved for this request
                queue_tabs[ proces_in_tab_id ] = {
                    request_id: request.id,
                    app_id: request.app_id,
                    is_help_request : is_help_request,
                    test_mode : test_mode
                };
                
                if ( account.return_gift_text == "NONE" ) {
                    queue_tabs[ proces_in_tab_id ].return_gift_text = '';                        
                } else if ( account.return_gift_text ) {
                    queue_tabs[ proces_in_tab_id ].return_gift_text = account.return_gift_text;    
                } else {
                    queue_tabs[ proces_in_tab_id ].return_gift_text = DEFAULT_RETURN_GIFT_TEXT;    
                }
                
            } );
        } else {
            
            // make sure this tab is reserved for this request
            queue_tabs[ proces_in_tab_id ] = "RESERVED";
        }
        
        // Open the already reserved tab
        open_request_in_tab( proces_in_tab_id, URI, function( request_tab ) {
            
            if ( app_defs[ request.app_id ] ) {
                   
                // To prevent break downs we here add a interval which reload the page
                // every 30 seconds until content script code finally manage to
                // do it on its own and finally marks it as done
                //console.log('Starts checking for break down on url(in 30s):' + URI );
                _checkForHang( proces_in_tab_id, request, URI, 0 );
                    
            } else {
                // Automatically finish this proces after 10 sec if there is no app definition
                // This way every app thinkable can be supported though with the return of a "thank you" gift
                setTimeout( function() {
                    finish_default_visual_request( proces_in_tab_id, request.id, request.app_id, 3, "" );
                }, 10000 );
            
            }             
        } );                
        
    } else {
        
        // Accept silently
    
        // Request app url
        jQuery.ajax({
            type: "GET",
            url: URI,
            timeout: 10000,
            dataType: 'text',
            success: function( data, textStatus, XMLHttpRequest ) {
                if ( step2 ) {
                    
                    var pos1 = data.indexOf( 'document.location.replace("' );
                    var pos2 = data.indexOf( '"', pos1 + 27 );
                    var text = data.slice( pos1 + 27, pos2 );
                    text = text.replace( /\\u0025/g, '%' );
                    text = text.replace( /\\/g, '' );
                    var url = $( '<div><p class="mylink" href="'+text+'">dummy</p></div>' ).find('p.mylink');
                    var URI2 = url.attr('href');
                    
                    // Do optional step 2 according to content of app result page
                    _requestAppUrlStep2( request, URI2, callback );
                    
                } else {
                    _procesAppResultPage( request, data, textStatus, XMLHttpRequest, URI, callback );
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                
                // Mark request as failed
                request.state = 5;
                request.state_text = 'Connection error(2):' + textStatus;
                
                // Save updated state and callback
                request.save( callback )		
            }
        });
    }
}

Request.prototype.proces = function( callback, manually ) {
    
    var request = this;
    var ui_action = this.action;
    
    // Load all info about request
    request.load( function( request ) {
        
        // Override action
        request.action = ui_action;
        
        // Prepare url for initial ajax call
        var url = request.ajax_init_data;
        if ( request.action == 'accept' ) {
            url = url.replace( '[[FVE_action_part]]', request.ajax_init_data_accept_part );
        } else if ( request.action == 'reject' ) {
            url = url.replace( '[[FVE_action_part]]', request.ajax_init_data_reject_part );
        }
        
        var post_url;
        
        if ( test_mode ) {
            
            post_url = 'http://192.168.1.10/fv_facebook/fb_proces_request_url.php';    
        } else {
            
            post_url = 'http://www.facebook.com' + request.ajax_init_script + '?__a=1';
        }
        
        // Do initial ajax call(removes request from facebook list)
        $.ajax({
            type: "POST",
            timeout: 10000,
            url: post_url,
            data: url,
            dataType: 'text',
            success: function(data, textStatus, XMLHttpRequest) {
                
                if ( request.action == 'accept' ) {                    
                
                    // If accept
                
                    // Extract app url from response
                    var temp_data = data;
                    var matches = temp_data.match( /goURI\((\\".*?\\")/ );
                    
                    if ( matches ) {
                    
                        eval( "var URI_temp = '" + matches[ 1 ] + "'" );
                        var app_url = JSON.parse( URI_temp );
                    
                        // Detect if step 2 is needed
                        var step2 = false;
                        if ( app_url.match( /\/l\.php/ ) ) {
                            app_url = 'http://www.facebook.com' + app_url;	
                            step2 = true;			
                        }
                        
                        if ( manually ) {
                            
                            // Return URL if manual mode
                            callback( [ request ], app_url )
                        
                        } else {
                            
                            // Request the app url
                            
                            if ( test_mode ) {
                                step2 = false;
                                app_url = 'http://192.168.1.10/fv_facebook/return_gift_no.html'; 
                                //app_url = 'http://192.168.1.10/fv_facebook/return_gift.php?rid=' + request.id;    
                            }  
                                
                           
                            // Check if there is an app definition                                
                            var silent_accept = false;
                            var help_request = false;
                            var app_def = app_defs[ request.app_id ];                                
                            if ( app_def ) {
                            
                                // Decide whether to accept this request silently or visually
                                // Check if a definer function is found
                                if ( app_def.functions.is_silent_accept ) {
                                    
                                    // Ask function for decision
                                    silent_accept = app_defs[ request.app_id ].functions.is_silent_accept( request, app_def );
                                }
                                
                                // Determine if this is a help request
                                // Check if a definer function is found
                                if ( app_def.functions.is_help_request ) {
                                    
                                    // Ask function for decision
                                    help_request = app_defs[ request.app_id ].functions.is_help_request( request, app_def );
                                }
                            }
                            
                            // Find available queue tab to open request in, if visually accept			
                            var proces_in_tab_id;
                            if ( !silent_accept ) {
                                for ( var tab_id in queue_tabs ) {
                                    
                                    if ( queue_tabs[ tab_id ] == null ) {
                                        
                                        // Reserve tab id for processing of this request
                                        queue_tabs[ tab_id ] = "RESERVED";
                                        
                                        proces_in_tab_id = tab_id;
                                        break;  
                                    }
                                }
                                
                                if (!proces_in_tab_id) {
                                    console.log( 'Not enough tabs for processing' );
                                }
                            }
                            
                            // Request app url
                            _requestAppUrl( proces_in_tab_id, request, help_request, app_url, step2, callback );
                            
                        }
                        
                    } else {
                        // Mark request as failed
                        request.state = 5;
                        request.state_text = "Unknown action for request(1)";
                        
                        // Save updated state and callback
                        request.save( callback );
                    }
                    
                } else if ( request.action == 'reject' ){
                    
                    // If reject
                    
                    // Mark request as done
                    request.state = 3;
                    
                    // Save updated state and callback
                    request.save( callback );
                    
                } else {
                    // Mark request as failed
                    request.state = 5;
                    request.state_text = "Unknown action for request(2)";
                    
                    // Save updated state and callback
                    request.save( callback );
                }
            },
            error: function( XMLHttpRequest, textStatus, errorThrown ) {
                request.state = 5;
                request.state_text = textStatus;
                
                // Save updated state and callback
                request.save( callback );
            }
        });
    } );
}

Request.prototype.getUniqueId = function() {
    return ( this.app_id + '_' + this.id );
}
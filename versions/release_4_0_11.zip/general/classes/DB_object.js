function DB_object() {
	
}

DB_object.prototype.save = function( callback ) {
	
	current_user_db.insertObjects( [ this ], 0, this.table, callback);
}

DB_object.prototype.load = function( callback ) {
	
	current_user_db.loadObject( this, this.table, callback );
}

DB_object.prototype.exportAllToCSV = function( callback, status_callback ) {
	current_user_db.exportAllObjectsToCSV( this, callback, status_callback );
}
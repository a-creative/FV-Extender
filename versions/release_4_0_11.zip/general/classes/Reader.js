function Reader( type ) {
    this.type = type;
}

function serialize_DOM_request ( app_name, app_link_href, app_icon_src, DOM_request ) {
	
	// The data form we get our info from
	var frm = DOM_request;
	
	// Get action url of the request
	var accept_btn_el = frm.find( 'input[name^="' + 'actions[http' + '"]' );	
	var action_url = escape( accept_btn_el.attr('name') );
	
	// Get id of the request (unique to the app )	
	var request_id;
	var new_request_id = frm.children('input[name=request_id]');
	var old_request_id = frm.children('input[name=id]');
	
	var old_request;
	if ( new_request_id.length ) {		
		old_request = false;
		request_id = new_request_id.val();
	} else {
		
		old_request = true;
		request_id = old_request_id.val();
	}
	
	
	
	var app_id = frm.find('input[name="params\[app_id\]"]').val();
		
	// Get FB id of the user this request was received from
	var from_id = frm.find('input[name="params\[from_id\]"]').val();
	
	// Create the partial ajax url for starting the accepting/rejecting process
	// [[FVE_action_part]] is later replaced to make the complete url
	
	var ajax_init_data;
	
	if ( action_url === 'undefined' ) {
		
		ajax_init_data = [
			'charset_test='					+ frm.children('input[name=charset_test]').val(),
			'post_form_id='					+ frm.find('input[name=post_form_id]').val(),
			'fb_dtsg='						+ frm.find('input[name=fb_dtsg]').val(),
			'id='							+ request_id,
			'params[from_id]='				+ from_id,
			'params[app_id]='				+ app_id,
			'div_id='						+ frm.children('input[name=div_id]').val(),
			'[[FVE_action_part]]',
			'lsd',
			'post_form_id_source='			+ 'AsyncRequest',
		];	
		
	} else if ( old_request ) {
		
		ajax_init_data = [
			'charset_test='					+ frm.children('input[name=charset_test]').val(),
			'id='							+ request_id,
			'type='							+ frm.children('input[name=type]').val(),
			'status_div_id='				+ frm.children('input[name=status_div_id]').val(),
			'params[from_id]='				+ from_id,
			'params[app_id]='				+ app_id,
			'params[req_type]='				+ frm.find('input[name="params\[req_type\]"]').val(),
			'params[is_invite]='			+ frm.find('input[name="params\[is_invite\]"]').val(),
			'lsd',
			'post_form_id_source='			+ 'AsyncRequest',
			'[[FVE_action_part]]',
			'post_form_id='					+ frm.find('input[name=post_form_id]').val(),
			'fb_dtsg='						+ frm.find('input[name=fb_dtsg]').val()
		];		
		
	} else {
		
		ajax_init_data = [
			'charset_test='					+ frm.children('input[name=charset_test]').val(),
			'post_form_id='					+ frm.find('input[name=post_form_id]').val(),
			'fb_dtsg='						+ frm.find('input[name=fb_dtsg]').val(),
			'request_id='					+ request_id,
			'type='							+ frm.children('input[name=type]').val(),
			'status_div_id='				+ frm.children('input[name=status_div_id]').val(),
			'params[from_id]='				+ from_id,
			'params[app_id]='				+ app_id,
			'params[req_type]='				+ frm.find('input[name="params\[req_type\]"]').val(),
			'params[is_invite]='			+ frm.find('input[name="params\[is_invite\]"]').val(),
			'[[FVE_action_part]]',
			'lsd',
			'post_form_id_source='			+ 'AsyncRequest',
		];
	}
	
	ajax_init_data_url = ajax_init_data.join( '&' );	
	
	// Get the user text	
	var user_text = '';
	var matches = DOM_request.html().match( /<div><strong>([^<]+)<\/strong><\/div>/ );
	if ( matches ) {
		user_text = matches[ 1 ];	
	}
	
	// Get the request text
	var system_text = '';
	var system_text_el = DOM_request.find('.appRequestBodyNewB' );
	
	if ( ! ( system_text_el && system_text_el.length ) ) {
		system_text_el = DOM_request.find('.appRequestBodyNewA' );
		
		if ( ! ( system_text_el && system_text_el.length ) ) {
			system_text_el = DOM_request.find('.streamStyleRequestBody, .appRequestBody');
		} 
	}
	
	if ( system_text_el && system_text_el.length ) {
		
		var system_text_el_cnt =  system_text_el.find('span');
		
		if ( system_text_el_cnt && system_text_el_cnt.length ) {
			system_text = system_text_el_cnt.html();
		} else {
			system_text = system_text_el.html();
		}
	}
	system_text = system_text.replace(/<[^>]+>/g, ''); // Remove HTML tags
	
	var request = new Request();        
	request.id = request_id;
	request.app_id = app_id;
	request.app_name = app_name;
	request.app_image = app_icon_src;
	request.app_link = app_link_href;
	request.ajax_init_script = frm.attr('action');
	request.ajax_init_data = ajax_init_data_url;
	request.user_text = user_text;
	request.text = system_text;
	request.action_url = action_url;
	
	
	if ( action_url === 'undefined' ) {
		request.ajax_init_data_accept_part = 'actions[accept]=' + frm.find('input[type="submit"]:first').attr('value');
	} else {
		request.ajax_init_data_accept_part = action_url + '=' + frm.find('input[type="submit"]:first').attr('value');
	}	
	
	request.ajax_init_data_reject_part = 'actions[reject]=';
        
	request.neighbor_id = from_id;
	
	var nb_name_el = DOM_request.find('a.UIImageBlock_SMALL_Image .uiTooltipText');
	if ( !nb_name_el.length ) {
		nb_name_el = DOM_request.find('.appRequestTitle strong a');		
	}
	
	if ( nb_name_el.length ) {
		request.neighbor_name = nb_name_el.html();
	}
		
	request.neighbor_image = DOM_request.find('a.UIImageBlock_SMALL_Image img').attr('src');
	
	return ( request );
}

function read_request( app_name, app_link_href, app_icon_src, DOM_request ) {
        
    // Transfer request from DOM to hash
    var request = serialize_DOM_request( app_name, app_link_href, app_icon_src, DOM_request );
    
    // Get the definition for the requests game
    var curr_app_def = app_defs[ request.app_id ];
    
	if ( curr_app_def ) {
		// If game is supported/defined
	
		if ( curr_app_def.functions.get_item_id ) {
			request.item_id = curr_app_def.functions.get_item_id( request );
		}
		
		if ( curr_app_def.functions.get_item_name ) {
			request.item_name = curr_app_def.functions.get_item_name( request );
		}
		
		// Item id is item name
		request.item_id = request.item_name;
	}
	
	return ( request );
}

Reader.prototype.execute = function( games_def, callback ) {
    if ( this.type === "requests" ) {    
		jQuery.ajax({
			type    : "GET",
			cache   : false,
			url     : GLOBAL_REQUESTS_URL,
			success: function( data ) {
				
				var orig_data = data;
				
				last_update_error = false;
							
				if ( abort_update() ) {
					return;
				}
			
				if ( data.indexOf( '<h2 class="uiHeaderTitle">Facebook Login</h2>' ) != -1 ) {
					last_update_error = {
						code : "login_problems",
						target_data: data
					}
					
					callback( false );
					return;	
				}
			
				// Find json value containing html for requests
				var begin = data.indexOf( '"content":{"pagelet_requests":"' ) + 10;
				var end = data.indexOf( '"}', begin ) + 2;
				var json_str_data = data.slice( begin, end );
				
				// Exit and callback imidiate if requests pagelet is empty
				if (
							( json_str_data === '{"pagelet_requests":""}' )
						||  ( json_str_data.indexOf( '<div id="pagelet_requests"></div>' ) != -1 )
						||  ( json_str_data.indexOf( '<div id="pagelet_requests" data-referrer="pagelet_requests"></div>' ) != -1 )
				) {
					log_info('empty requests');
					callback( [] );
					return;
				}
					
				// If so parse json data to html				
				var json_data = {};
				try {
					json_data = JSON.parse( json_str_data );
					
					last_update_error = false;
				} catch( e ) {
					
					last_update_error = {
						code : "json_error",
						exception: e,
						target_data: orig_data
					}
					
					callback( false );
					return;
				}
				
				var html_data = json_data.pagelet_requests;
				
				// Convert it to jQuery el
				data = jQuery( '<div>' +  html_data + '</div>' )
				
				// Create global var for requests
				var requests = [];			
							
				var app_groups_read_count = 0;
				
				var app_groups = data.find( '.appRequestGroup' );
				
				// App groups should be present
				if ( app_groups.length === 0 ) {
					
					// Report error if not
					last_update_error = {
						code : "app_group_count_error",
						target_data: orig_data
					}
					
					callback( false );
					return;		
				} else {
					last_update_error = false;
				}				
				
				// Loop app groups asynch.
				try {
					app_groups.each( function(i, app_group ) {
						var app_name 		= '',
							app_link_href	= '',
							app_icon_src 	= '';
							
						var app_img_el = $(app_group).children().first();
						if ( app_img_el.length ) {
							
							var app_img_cont_el = app_img_el.find( 'img' );
							if ( app_img_cont_el.length ) {
								app_icon_src = app_img_cont_el.attr( 'src' );	
							}
							
							var app_name_el = app_img_el.next().find('> a > strong' );
							if ( app_name_el.length ) {
								app_name = app_name_el.html();
							} else {							
								app_name_el = app_img_el.next().find( '> div > a > strong ');
							}
							
							if ( app_name_el.length ) {
								app_name = app_name_el.html();
								
								var app_link_el = app_name_el.parent();
								if ( app_link_el.length ) {
									app_link_href = app_link_el.attr( 'href' );
								}
							}
						}						
					
						var DOM_requests = $(app_group).find( 'ul.requests > li > form' );
						
						// There should be requests below this app
						if ( DOM_requests.length == 0 ) {
							
							// Report error if not
							last_update_error = {
								code : "request_count_error",
								target_data: $(app_group).html()
							}
							
							callback( false );
							return;	
						} else {
							last_update_error = false;
						}
						
						app_groups_read_count++;
						
						var DOM_requests_read_count = 0;
						DOM_requests.each( function( i, DOM_request ) {
							requests.push( read_request( app_name, app_link_href, app_icon_src, $(DOM_request) ) );							
							DOM_requests_read_count ++;
							if ( ( app_groups_read_count == app_groups.length ) && ( DOM_requests_read_count == DOM_requests.length ) ){
								
								// Finish when all app groups and request below has been read
								callback( requests );																		
							}
						});
					});
				} catch( e ) {
					last_update_error = {
						code : "request_loop_error",
						exception: e
					}
					
					callback( false );
					return;	
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				
				last_update_error = {
					code : "request_read_ajax_conn_err",
					textStatus: textStatus,
					errorThrown: errorThrown,
					target_data: GLOBAL_REQUESTS_URL
				};
				
				callback( false );
			}
		});
    }
};


var databases = {};
var current_user_db = null;

var master_db = null;

function DB( user_id ) {
    var db;
    
    if ( user_id && databases[ user_id ] ) {
        db = databases[ user_id ];
        log_info('Got cached user db:' + db );
    } else if ( ( !user_id ) && databases.master) {
        db = databases.master;
        log_info('Got cached master db');
        log_info('uid:' + user_id);
        
        
    } else {

        try {
            if ( openDatabase ) {
                
                var db_name = '';
                var db_description = '';
                
                if ( user_id ) {
                    db_name = "FV_Extender_" + user_id;
                    db_description = "FV Extender FB user storage";
                    
                } else {
                    db_name = "FV_Entender master";
                    db_description = "FV Extender master storage";
                }
                
                log_info('Creating DB with name:' + db_name );
                db = openDatabase( db_name, "1.0", db_description, 5 * 1024 * 1024);
                if (!db) {
                    log_error( "Failed to open the database on disk.  This is probably because the version was bad or there is not enough space left in this domain's quota" );
                } else {
                    db.onError = function( e ) {
                        
                        log_error( e.message );
                        
                        
                    };                                
                }
            } else {
                log_error("Couldn't open the database.  Please try with a WebKit nightly with this feature enabled");
            }
        } catch(err) {  
            FVE_alert( err );         
        }
        
        if ( user_id ) {
            databases[ user_id ] = db;
        } else {
            databases.master = db;
            this.is_master = true;
        }
    }
    
    this.handle = db;       
}

DB.prototype.recreate = function( callback ) {
    if ( this.handle ) {
        
        var db = this.handle;
        
        this.handle.transaction(
            function( t ) {
                t.executeSql( 'drop table if exists account' );
                t.executeSql( 'drop table if exists requests' );
                t.executeSql( 'drop table if exists items' );
                t.executeSql( 'drop table if exists install' );
                t.executeSql( 'drop table if exists app_settings' );
            },
            db.onError,
            callback
        );
    }
};

DB.prototype.onError = function( obj, exception ) {
    log_error('DB error:' + exception.message );
};

DB.prototype.onSuccess = function( evt ) {
    log_info('DB success' ); 
};

DB.prototype.init = function( callback ) {
    var Class = this;
    var db = this.handle;
    
    if ( this.is_master ) {
        this.handle.transaction(
            function( t ) {
                Class.initTable( t, new Install(), "install" );
            },
            db.onError,
            callback
        ); 
    } else {
        this.handle.transaction(
            function( t ) {
                Class.initTable( t, new Request(), "requests" );
                Class.initTable( t, new Item(), "items" );
                Class.initTable( t, new Account(), "account" );
                Class.initTable( t, new AppSettings(), "app_settings" );
            },
            db.onError,
            callback
        );
    }
};

DB.prototype.initTable = function( t, class_object, table_name ) {
    var attr_name;
    
    var attrs = class_object.attrs;
    
    var sql_fields = [];
    for ( attr_name in attrs ) {
        if ( attrs.hasOwnProperty( attr_name ) ) {
            sql_fields.push( attr_name + ' ' + attrs[ attr_name ] );  
        }
    }
    
    sql_fields = sql_fields.join(',');
    
    this.handle.transaction(function( t ) {
        var sql_st = 'create table if not exists '
             +   table_name + '('
             +      sql_fields
             +   ')';
        
        t.executeSql(
             sql_st,
             [],
             this.onSuccess,
             this.onError
        );
    }); 
};

DB.prototype.getNumberOfObjectsWithState = function( state, callback ) {
     // Get database handle
    if ( this.handle ) {
        // Start DB transation
        this.handle.readTransaction( function( t ) {
            var sql_st = 'select count(*) from requests where state = "' + state + '"';
            t.executeSql(
                sql_st,
                [],
                function( t, rs ) {
                    var row = rs.rows.item(0);
                    var count = row[ "count(*)" ];
                    callback( count );                    
                },
                this.onError
            );
        });
    }
};

DB.prototype.insertObjects = function( objects, i, table, callback, onError ) {
    
    if ( objects.length > 0 ) {
       
        var Class = this;
        var db = this.handle;
        
        if ( !onError ) {
            onError =  db.onError;
        }
        
        db.transaction(
            function( t ) {
                
                 Class.saveObject(t, objects[ i ], table, onError );  
            },
            function ( err ) {
                onError( null, err ); 
            },
            function() {
                i++;
                
                if ( i < objects.length && (!abort_update() ) ) {
                    Class.insertObjects( objects, i, table, callback, onError );    
                } else {
                    if ( callback ) callback( objects );                
                }
            }            
        );
    } else {
        if ( callback ) callback();
    }
};

DB.prototype.getAllAppSettingsHash = function ( callback ) {
    this.getObjectsHash( 'AppSettings', 'app_settings', callback );    
}

DB.prototype.getObjectsHash = function( class_name, table_name, callback ) {
    this.handle.readTransaction(  function( t ) {
        var sql_st = 'select * from ' + table_name;
        
        t.executeSql(
            sql_st,
            [],
            function( t, rs ) {
                
                var objects = {};
                var eval_str = '';
                
                var id;
                
                
                for ( var i = 0; i < rs.rows.length; i++ ) {
                    id = rs.rows.item( i ).id;
                    
                    eval_str += 'objects[ ' + id + ' ] = new ' + class_name + '();';
                    eval_str += 'jQuery.extend( objects[ ' + id + ' ], rs.rows.item( ' + i + ' ) );'
                }
                
                if ( eval_str ) {
                    eval ( eval_str );
                }                
                
                if ( callback ) callback( objects );
            },
            function ( t, e ) {
                log_error('e:' + e.message )
            }
        );
    } );
    
};

DB.prototype.loadObject = function( baseObject, table_name, callback ) {
    var sql_st;
    
    var sel_values;
    if ( baseObject.attrs.app_id ) {
        sel_values = [ baseObject.id, baseObject.app_id ]; 
        sql_st = 'select * from ' + table_name + ' where id = ? and app_id = ?';
    } else {
        sel_values = [ baseObject.id ]; 
        sql_st = 'select * from ' + table_name + ' where id = ?';
    }
    
    var Class = this;
    var db = this.handle;
    
    db.readTransaction( function( t ) {
        
        t.executeSql(
            sql_st,
            sel_values,
            function( t, rs ) {
                
                if ( rs.rows.length > 0 ) {
                
                    var attrs = baseObject.attrs;
                    var attr_name;
                    
                    var db_object = rs.rows.item( 0 );
                    
                    for ( attr_name in attrs ) {
                        baseObject[ attr_name ] = db_object[ attr_name ];    
                    }
                    
                    callback( baseObject );
                } else {
                    callback( null );
                }
            },
            this.onError
        )
    });
    
}

DB.prototype.saveObject = function( t, object, table_name, onError ) {
    
    if (!onError) {
        onError = this.onError;
    }
    
    var sql_st;
    var obj_value;
    
    // Query if the object with this id already exists in the database
    
    var selValues;
    
    var added_time_sel_sql = '';
    if ( object.attrs.hasOwnProperty( 'added_time' ) ) {
        added_time_sel_sql = ', added_time';
    }
    
    if ( object.attrs.app_id ) {
        sql_st = 'select id' + added_time_sel_sql + ' from ' + table_name + ' where id = ? and app_id = ?';
        selValues = [ object.id, object.app_id ];
    } else {
        sql_st = 'select id' + added_time_sel_sql + ' from ' + table_name + ' where id = ?';
        selValues = [ object.id ];
    }
    
    t.executeSql(
        sql_st,
        selValues,
        function( t, rs ) {
            if ( rs.rows.length === 0 ) {
                
                // If it doesn't exist already
                
                // Insert object
                
                var attrs = object.attrs;
                
                var sql_keys = [];
                var values = [];
                var sql_values = [];
                
                var attr_name;
                var value;
                for ( attr_name in attrs ) {
                    if ( attrs.hasOwnProperty( attr_name ) ) {
                        value = object[ attr_name ];
                        
                        if ( value != undefined ) {
                            sql_keys.push ( attr_name );
                            values.push( value  );
                            sql_values.push( '?' );
                        } else if ( attr_name == 'added_time' ) {
                            
                            var now = new Date().getTime();
                            
                            sql_keys.push ( attr_name );
                            values.push( now  );
                            sql_values.push( '?' );
                        }
                    }
                }
                
                sql_keys = sql_keys.join(', ');
                sql_values = sql_values.join(', ');
                
                
                
                sql_st =
                    'insert into ' + table_name
                +   '('
                +       sql_keys
                +   ') '
                +   'values('
                +       sql_values
                +   ')';
                
                //log_info('Creating object:' + sql_st + ':(' + values.join(', ')+ ')' );
                               
                t.executeSql(
                    sql_st,
                    values,
                    this.onSuccess,
                    function ( tx, err ) {
                        onError( tx, err, sql_st, values ); 
                    }
                    
                );                
            } else {
                
                // If the object does exists
                
                // Update element
                
                var attrs = object.attrs;
                
                var sql_updates = [];
                var values = [];
                
                var attr_name;
                var value;
                for ( attr_name in attrs ) {
                    if ( attrs.hasOwnProperty( attr_name ) ) {
                        value = object[ attr_name ];
                        
                        if ( attr_name == 'updated' ) {
                            
                            // If attribute 'updated'
                            
                            // Override with current time
                            values.push( new Date().getTime() );
                            sql_updates.push( attr_name + ' = ?')
                        } else if ( value != undefined ) {
                            
                            // If other attribute and it is defined
                            
                            // Update it
                            values.push( value );
                            sql_updates.push( attr_name + ' = ?')
                        } else if ( ( attr_name == 'added_time' ) && ( rs.rows.item(0).added_time === 'undefined' ) ) {
                            
                            var now = new Date().getTime();
                            
                            // Create with current time
                            values.push( new Date().getTime() );
                            sql_updates.push( attr_name + ' = ?')
                        }
                    }
                }
              
                sql_updates = sql_updates.join(', ');
                
                
                if ( attrs.app_id ) {
                    values.push( object.id );
                    values.push( object.app_id );
                    
                    sql_st =
                        'update ' + table_name + ' '
                    +   'set ' + sql_updates + ' '
                    +   'where id = ? and app_id = ?'
                } else {
                    values.push( object.id );
                    
                    sql_st =
                        'update ' + table_name + ' '
                    +   'set ' + sql_updates + ' '
                    +   'where id = ?'
                }
                
                //log_info('UPDATE: "' + sql_st + '": "' + values.join( '", "' ) + '"' );
                                
                t.executeSql(
                    sql_st,
                    values,
                    this.onSuccess,
                    function ( tx, err ) {
                        onError( tx, err, sql_st, values ); 
                    }
                );                        
            }
        }
    );
};

DB.prototype.insertItem = function( t, item ) {
    this.saveObject(t, item, 'items' );  
};

DB.prototype.insertApp = function( t, app ) {
    this.saveObject(t, appp, 'apps' );  
};

DB.prototype.insertApps = function( apps, callback ) {
    this.insertObjects( apps, 0, 'apps', callback );
}

DB.prototype.saveRequests = function( requests, callback, cbOnError ) {
    this.insertObjects( requests, 0, 'requests', callback, cbOnError );
}

DB.prototype.updateAccount = function( account, callback ) {
    var db = this.handle;
    
    var Class = this;
        
    db.transaction(
        function( t ) {
             Class.saveObject( t, account, 'account' );  
        },
        db.onError,
        function() {
            if ( callback ) {
                callback();
            }
        }        
    );
};

DB.prototype.getAppsIdsFromReadyRequests = function( callback ) {
    this.handle.readTransaction(  function( t ) {
        var sql_st = 'select app_id, app_name from Requests where state = 0 group by app_id';        
        t.executeSql(
            sql_st,
            [],
            function( t, rs ) {
                
                var apps = [];
                for ( var i = 0; i < rs.rows.length; i++ ) {
                    apps.push( {
                        id : rs.rows.item( i ).app_id,
                        name : rs.rows.item( i ).app_name
                    } );    
                }
                
                if ( callback ) callback( apps );
            },
            function ( t, e ) {
                log_error('e:' + e.message )
            }
        );        
    });    
}

DB.prototype.getReadyRequestsOrderedByItemFromAppId = function ( app_id, callback ) {
    
    this.handle.readTransaction(  function( t ) {
        var sql_st = 'select * from requests where app_id = ' + app_id + ' and ( state = 0 ) order by item_name asc, item_id desc';
        
        t.executeSql(
            sql_st,
            [],
            function( t, rs ) {
                var request;
                var requests = [];
                
                
                for ( var i = 0; i < rs.rows.length; i++ ) {
                    var request = new Request();
                    jQuery.extend( request, rs.rows.item( i ) );
                    request.app_def = app_defs[ request.app_id ];
                    
                    requests.push( request );    
                }
                
                if ( callback ) callback( requests, app_id );
            },
            function ( t, e ) {
                log_error('e:' + e.message )
            }
        );        
    });            
};

DB.prototype.getDefaultActionForRequest = function( request, callback ) {
    this.handle.readTransaction(  function( t ) {
        var sql_st = 'select default_action from items where app_id = ? and id = ?';
        
        t.executeSql(
            sql_st,
            [ request.app_id, request.item_id ],
            function( t, rs ) {
                
                if ( callback ) {
                    if ( rs.rows.length > 0 ) {
                        callback( request, rs.rows.item( 0 ).default_action );
                    } else {
                        callback( request, "");
                    }
                }
            },
            function ( t, e ) {
                log_error('e:' + e.message )
            }
        );        
    });               
}

DB.prototype.getAppAutoAcceptEnabled = function ( app_id, callback ) {
    this.handle.readTransaction(  function( t ) {
        var sql_st = 'select default_action from items where app_id = ? and id = ?';
        
        t.executeSql(
            sql_st,
            [ request.app_id, request.item_id ],
            function( t, rs ) {        
                if ( callback ) {
                    if ( rs.rows.length > 0 ) {
                        callback( request, rs.rows.item( 0 ).default_action );
                    } else {
                        callback( request, "");
                    }
                }
            },
            function ( t, e ) {
                log_error('e:' + e.message )
            }
        );        
    });         
}

DB.prototype.exportAllObjectsToCSV = function( objClass, callback, status_callback ) {
    
    
    var keys = Object.keys( objClass.attrs );
    
    var sql_st = 'select ' + ( keys.join(', ') ) + ' from ' + objClass.table;
    
    status_callback( 'Loading...');
    
    this.handle.readTransaction(  function( t ) {
        t.executeSql(
            sql_st,
            [],
            function( t, rs ) {
                
                status_callback( 'Done loading...');
                var row;
                var csv = '';
                
                if ( rs.rows.length > 0 ) {
                    
                    var columns = [];
                    for ( var i = 0; i < keys.length; i++ ) {
                        columns.push ( '"' + keys[ i ] + '"' );
                    }
                    
                    csv += columns.join( ';' ) + '\n';                  
                }
                
                for ( var i = 0; i < rs.rows.length; i++ ) {
                    status_callback( 'Exporting:' + ( i + 1 ) + ' of ' + rs.rows.length );
                    row = rs.rows.item( i );
                    
                    var vals = [];
                    for ( var key in row ) {
                        vals.push( '"' + row[ key ] + '"' );    
                    }
                    
                    csv += vals.join( ';') + '\n';
                }
                
                callback ( csv );
            },
            function ( t, e ) {
                callback('e:' + e.message )
            }
        );        
    });      
    
}
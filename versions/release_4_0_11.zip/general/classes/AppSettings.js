function AppSettings() {
    
    this.table = 'app_settings';    
    this.attrs = {        
        "id" : "INTEGER PRIMARY KEY",
        "manuallyAccept" : "INTEGER"
    };    
}

AppSettings.prototype = new DB_object();

AppSettings.prototype.getAllHash = function ( callback ) {
    current_user_db.getAllAppSettingsHash( callback );
    
}
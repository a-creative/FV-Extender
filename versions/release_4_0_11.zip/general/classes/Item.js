function Item() {
    this.table = 'items';    
    this.attrs = {        
        "id" : "TEXT PRIMARY KEY",
        "default_action" : "TEXT", // accept or reject
        "app_id" : "TEXT"
    };    
}

Item.prototype = new DB_object();

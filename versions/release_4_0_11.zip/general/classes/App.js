function App() {
    this.attrs = {        
        "id" : "INTEGER PRIMARY KEY",
        "active" : "INTEGER",
        "enabled" : "INTEGER DEFAULT 1",
        "priority" : "INTEGER DEFAULT 999", // 999 = unset, 1000 = neutral/all
        "updated" : "INTEGER"
    };    
}

/*
App.prototype.getAllEnabled = function( callback ) {
    current_user_db.getAllEnabledApps( function( rows ) {
        var apps = [];
        var app;
        for ( var i = 0; i < rows.length; i++ ) {
            app = new App();
            app.id = rows.item( i ).id;
            app.active = 1;
            app.enabled = 1;
            app.priority = rows.item( i ).priority;
            apps.push( app);    
        }
        
        callback( apps );
    } );
};

App.prototype.setDefault = function( app, callback ) {
    var app_id;
    if ( isNaN( app ) ) {
        app_id = app.id;
    } else {
        app_id = app;
    }
    
    alert('initiating setDefault:' + app_id );
    
    current_user_db.setDefaultApp( app_id, callback );
}

App.prototype.updateAllFromFB = function( callback ) {
    
    // Update apps information
    jQuery.get( 'http://www.facebook.com/settings/?tab=applications', function( html ) {
        var el = $( FVE_clean_html( html ) );
        
        // Loop all app definitions
        var app_el;
        var apps = [];
        for ( var app_id in app_defs ) {
            var app = new App();
            app.id = app_id;
            
            // Detect if user has it active 
            app_el = el.find('#application-li-' + app_id );
            if ( app_el.length ) {
                app.active = 1;																
            } else {
                app.active = 0;
            }
            
            apps.push( app );
        }
        current_user_db.insertApps( apps, callback );
    });
}
*/

App.prototype.getFromReadyRequests = function( callback ) {
    
    current_user_db.getAppsIdsFromReadyRequests( function( input_apps ) {
        
        var standard_sup = [];
        var partial_sup = [];
        var apps = [];        
        
        var app_def;
        var input_app;
        var app;
        for ( var i = 0; i < input_apps.length; i++ ) {
            input_app = input_apps[ i ];
            app = new App();
            app.id = input_app.id;
            app.name = input_app.name;
            app.def = app_defs[ app.id ];            
            
            
            if ( app.def ) {
                if ( ( app.def.accept_support == 'auto' ) && ( app.def.customer_support == 'fast' ) ) {
                    apps.push( app );
                } else {
                    partial_sup.push( app )
                }
            } else {
                standard_sup.push( app );
            }
        }
        
        apps =  apps.concat( partial_sup );
        apps =  apps.concat( standard_sup );       
        
        callback( apps );
    } ); 
    
}
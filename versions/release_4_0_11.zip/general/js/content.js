var FVE_request;
var FVE_callback;
var FVE_app_def;
var FVE_app_id;
var FVE_test_mode;

function finish_request( app_id, request_id, state, state_text, callback, result_page_html ) {
	if ( FVE_test_mode === true ) {
		var rnd_id = Math.floor( ( Math.random() * 6000) ) + 1;
		
		setTimeout( function() {
			chrome.extension.sendRequest( {
				action: "finish_default_visual_request",
				app_id: app_id,
				request_id: request_id,
				state: state,
				state_text: state_text,
				result_page_html: result_page_html
			}, function() {		
				// And ignore onChange handling by returning true for handled
				callback();
			} );	
		}, 2000 + rnd_id );
		
	} else {
	
		chrome.extension.sendRequest( {
			action: "finish_default_visual_request",
			app_id: app_id,
			request_id: request_id,
			state: state,
			state_text: state_text
		}, function() {		
			// And ignore onChange handling by returning true for handled
			callback();
		} );
	} 
}


$(document).ready( function() {
			
    function callLast(func, t){
            if(!t){ t = 100; }
            var callLastTimeout = null; 
            return function(){
                    if(callLastTimeout!==null){
                            window.clearTimeout(callLastTimeout); 
                    }
                    callLastTimeout = window.setTimeout(function(){ callLastTimeout = null; func(); }, t);
            };
    }
    
    function run(){		
            function work(){
				removeWorker();
				FVE_app_def.functions.processResultPageVisualOnChange( FVE_request_id, FVE_return_gift_text );
				addWorker();
            }
    
            var workLast = callLast(work);
            function addWorker(){       document.addEventListener("DOMSubtreeModified", workLast, false); }
            function removeWorker(){ document.removeEventListener("DOMSubtreeModified", workLast, false); } 
            function startWork(){ addWorker(); workLast(); }
    
            startWork();
    }
	
	// Get identity of the current app and inject. app defnition
	console.log( 'Requests for tab info');
	chrome.extension.sendRequest( { action: "get_tab_info" }, function( tab_info ) {
		console.log( 'Got tab info');
		if ( tab_info ) {
			
			// Find request and app def. from tab
			FVE_request_id = tab_info.request_id;
			FVE_app_id =  tab_info.app_id;
			FVE_app_def = app_defs[ FVE_app_id ];
			FVE_is_help_request = tab_info.is_help_request;
			FVE_return_gift_text = tab_info.return_gift_text;
			FVE_test_mode = tab_info.test_mode;
			
			console.log( 'Got valid tab info:' + tab_info.request_id );
			
			// Do app specific stuff to finish this proces the right way	
			if ( FVE_app_def && FVE_request_id && FVE_app_id ) {
					
				// If FVE has app defined
				// Run app specific handling
				console.log( 'App HAS def. Starting app specific run' );
				
				// First we check for shortcut onload
				FVE_app_def.functions.processResultPageVisualOnLoad( FVE_app_id, FVE_request_id, FVE_is_help_request, function( handled ) {
					if ( !handled ) {
						// If finishing wasn't handled onload try doing it onchange
						console.log('onChange');
						run();
					}
				})
				
			}
		}
	} );	
});

function if_not_detected( el, func ) {
	if ( el.attr( 'FV_Extender_detected' ) != 'true' ) {
		el.attr('FV_Extender_detected', 'true' );
		func( el );
	}	
}

console.log( 'Content loaded' );
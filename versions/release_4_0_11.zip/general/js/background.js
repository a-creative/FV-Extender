log_info('FV Extender starting up...');

// Show version
var FVE_version = getVersion();
log_info( "Version:" + FVE_version );

// Game definitions loaded in object "game_definition"

var test_mode = false;

var current_user_id = -1;
var current_lang_id = 'en';

var current_install = null;

var curr_transl = GLOBAL_transl[ current_lang_id ];

var GLOBAL_requests = [];


var GLOBAL_REQUESTS_URL
if ( test_mode ) {
	GLOBAL_REQUESTS_URL = 'http://192.168.1.10/fv_facebook/test_games.html';
	
} else {
	GLOBAL_REQUESTS_URL = 'http://www.facebook.com/games?ap=1';
}

var GLOBAL_INFO_PAGE_URL = 'http://fvextender.blogspot.com/feeds/posts/default?alt=rss';
var ABORT_RESERVED_WARNING = "Abort due to closing of working tabs. <a target='_blank' href='http://getsatisfaction.com/fv-extender/topics/tabs_opening_when_clicking_on_process_requests'>Read more</a>. Click on 'Update request list' to start over.";

var DEFAULT_RETURN_GIFT_TEXT = 'This gift was returned using FV Extender.';

var app_tab = null;
var ask_for_login = false;
var login_activated = false;
var current_login = null;

var main_dialog_url = 'dialogs/main/html/index.html';

var reader = null;

var data_update_timer_id = null;
var abort_current_update = false;
var last_update_error = false;

var loader_interval_id = null;
var loading_index = 1;

var update_active = false;

var ask_for_abort_queue = false;
var abort_reason = '';


var update_start_time = 0;

// Queue var.
var DEFAULT_MAX_PROCS_COUNT_SEC = 2;
var max_procs_count_sec = DEFAULT_MAX_PROCS_COUNT_SEC;
var running_procs_count = 0;
var queued_requests = [];
var done_requests = [];
var queue_tabs = {};

var current_requests_count = 0

var UPDATE_INTERVAL_SIZE = 5 *  60 * 1000 ;
var duration_of_last_update = UPDATE_INTERVAL_SIZE;

function FVE_clean_html ( dirty_html ) {
	var clean_html;
	
	if( dirty_html.indexOf( '<body' ) != -1 ) {
		 clean_html = dirty_html.slice( dirty_html.indexOf( '<body' ), dirty_html.lastIndexOf('</body') + 7 );
	}
	else {
		clean_html = '<div>' + dirty_html + '</div>';
	}
	
	return  clean_html;
}

function getVersion() {
	
	var xhr = new XMLHttpRequest();
	
	var manifest;
	if ( xhr ) {
		xhr.open('GET', chrome.extension.getURL('manifest.json'), false);
		xhr.send(null);
		try {
			manifest = JSON.parse( xhr.responseText );
		} catch( e ) {			
			log_error( e.message );
		}
	}
		
	if ( manifest && manifest.version ) {
		return manifest.version;
	} else {
		return ( 'Could not detect version' );
	}
	
}

function FVE_AppClass() {
	return new App();
}

function FVE_AppSettingsClass() {
	return new AppSettings();
}

function FVE_RequestClass() {
	return new Request();
}

function FVE_InstallClass() {
	return new Install();
}


function FVE_ItemClass() {
	return new Item();
}


function get_app_tab_dom() {
	
	if ( app_tab ) {
		var views = chrome.extension.getViews({
			type : "tab"
		});
		
		if ( views.length ) {
			return views[ 0 ]
		} 
	}
	
	return false;
}

function FVE_update_counter ( db, callback ) {
    db.getNumberOfObjectsWithState( 0, function( count ) {
        
		if ( count > current_requests_count ) {			
			inform_UI_about_new_requests( count - current_requests_count );			
		}
		
		current_requests_count = count;
		
		       
		if ( count === 100 ) {
			count = '100+'
		} else if ( count === 0 ) {
            count = '';
        } else {
            count = '' + count;
        }
        
        chrome.browserAction.setBadgeBackgroundColor({ color:[0, 0, 0, 255] });
        chrome.browserAction.setBadgeText({ text : count  });
        
        log_info('Counter updated.');
        
        callback();
    });    
}

function _FVE_counter_updated() {
	
	log_info( 'Update done!' );
	
	// Mark that update is inactive
	update_active = false;
	
	data_update_timer_id = null;
	
	// Record time of this update
	duration_of_last_update = new Date().getTime() - update_start_time;
	log_info( "Update duration(sec):" + ( duration_of_last_update / 1000 ) );
	
	// Schedule next update
	FVE_update_cycle();	
}

function _FVE_requests_saved() {
    if ( !abort_update() ) {
		log_info('Requests saved.');
			
		// Update toolbar counter
	   
		FVE_update_counter( current_user_db, _FVE_counter_updated );
	}
}

function FVE_reset_update_cycle() {
	// Set update to be inactive
	update_active = false;
	data_update_timer_id = null;
	
	// Set duration of failed update to zero, so delay for next update is full
	duration_of_last_update = 0;
	
	// Schedule next update after this failed one
	FVE_update_cycle();	
}

function _FVE_requests_read( requests, errorThrown ) {
    if ( requests === false ) {
		
		// Reading of requests from Facebook failed
				
		FVE_reset_update_cycle();
		
	} else {
	
		log_info('Requests read.');
		
		if ( ! abort_update() ) {			
			
			if ( current_user_db && current_user_db.saveRequests ) {
				last_update_error = false;
				
				current_user_db.saveRequests( requests, _FVE_requests_saved, function( tx, err, sql_st, sql_values ) {
				
					// on error
					last_update_error = {
						code : "db_error",
						sql_st: sql_st,
						sql_values: sql_values,
						err: err
					}
					
					FVE_reset_update_cycle();
					
				});
				
			} else {
				
				last_update_error = {
					code : "wrong_db_object_err",
					target_data: current_user_db
				}
				
				FVE_reset_update_cycle();
			}
		}
	}
}

function FVE_update_cycle( requested ) {
    
	if ( requested ) {
		
		log_info( 'UI requests instant data update!');
		
		// If this cycle was requested by frontend
		if ( data_update_timer_id ) {
			
			// Reset current schedule
			clearTimeout( data_update_timer_id );
			data_update_timer_id = null;
		}
		
		// Set delay to none so it runs instantly
		duration_of_last_update = UPDATE_INTERVAL_SIZE;
		
		// Activate lock on database
		update_active = true;
		
	}
	
	// Calculate how much to delay the update
	var now = new Date().getTime();
	var next_update_delay = UPDATE_INTERVAL_SIZE - duration_of_last_update;
	if ( next_update_delay < 0 ) {
		
		// If last update startet longer than default update duration
		
		// Start update immediatly
		next_update_delay = 0;
	}
	
	// Schedule update according to calculated delay
	log_info( "Scheduling next update in(sec):" + ( next_update_delay / 1000 ) + " at " + ( new Date( now + next_update_delay ).toLocaleString() ) );
	
	if ( data_update_timer_id == null ) {
		data_update_timer_id = setTimeout( FVE_update, next_update_delay );
	} else {
		log_warn( "Update timeout not set because one was already there" );
	}
    
}

function FVE_update() {
	log_info("Starting update");
	
	// Mark that update is active
	update_active = true;
	
	// Record start time of update( to calculate duration of update in the end)
	update_start_time = new Date().getTime();
	
	// Read requests from facebook
	reader = new Reader( 'requests' );
    reader.execute( app_defs, _FVE_requests_read );
}

function _FVE_FB_login() {
	login_activated = true;
    chrome.tabs.create( { url: "http://www.facebook.com/login.php" }, function( tab ) {
        app_tab = tab;
	});    
}

function _FVE_show() {
    if ( app_tab ) {
                
        chrome.tabs.get( app_tab.id, function( tab ) {
			if ( tab ) {
                chrome.tabs.update( tab.id,{ selected: true } );    
            } else {
                chrome.tabs.create( { url: main_dialog_url }, function( tab ) {
                    app_tab = tab;
                });                            
            }
        }); 
     } else {
        chrome.tabs.create( { url: main_dialog_url }, function( tab ) {
            app_tab = tab;

        });
     }
}

function FVE_deactivated( is_loading ) {
    var i;
    
    if ( is_loading ) {
        
        chrome.browserAction.setBadgeBackgroundColor({ color:[0, 0, 0, 255] });
        chrome.browserAction.setBadgeText({ text : '.  ' });
        chrome.browserAction.setTitle({ title :"FV Extender 4 - Loading. Please wait..."});
        
        loading_index = 2;
        
        loader_interval_id = setInterval( function(){
            
            var loading_text = '';
            for ( i = 0; i < 3; i++ ) {
                if ( i < loading_index ) {
                    loading_text += '.';
                } else {
                    loading_text += ' ';
                }
            }
            
            chrome.browserAction.setBadgeText({ text : loading_text });
            
            loading_index++;
            if ( loading_index > 3 ) {
                loading_index = 1;
            }
        },250 );
    } else {
        chrome.browserAction.setBadgeText({ text : "x" });
        chrome.browserAction.setBadgeBackgroundColor({ color:[0, 0, 0, 255] });
        chrome.browserAction.setTitle({ title :"FV Extender 4 - Inactive: Click to activate"});
    }
    
    chrome.browserAction.setIcon({ path :"general/img/chrome_16_off.gif"});    
    
    if ( chrome.browserAction.onClicked.hasListener( _FVE_FB_login ) ) {
        chrome.browserAction.onClicked.removeListener( _FVE_FB_login );
    }
    
    if ( chrome.browserAction.onClicked.hasListener( _FVE_show ) ) {
        chrome.browserAction.onClicked.removeListener( _FVE_show );
    }
	
	if ( app_tab ) {
		chrome.tabs.remove( app_tab.id );
	}
    
    ask_for_login = true;
    
    chrome.browserAction.onClicked.addListener( _FVE_FB_login );
}

function FVE_activated() {
    chrome.browserAction.setBadgeText({ text : "" });
    chrome.browserAction.setBadgeBackgroundColor({ color:[0, 0, 0, 255] });
    chrome.browserAction.setIcon({ path :"general/img/chrome_16.gif"});
    chrome.browserAction.setTitle({ title :"FV Extender 4 - Click to show"});
    
    if ( loader_interval_id ) {
        clearInterval( loader_interval_id );
        loader_interval_id = null;
    }
    
    if ( ask_for_login ) {
        
        if ( chrome.browserAction.onClicked.hasListener( _FVE_FB_login ) ) {
            chrome.browserAction.onClicked.removeListener( _FVE_FB_login );
        }
        
        if ( chrome.browserAction.onClicked.hasListener( _FVE_show ) ) {
            chrome.browserAction.onClicked.removeListener( _FVE_show );
        } 
       
        chrome.browserAction.onClicked.addListener( _FVE_show );                
        
        ask_for_login = false;
    }
	
	if ( login_activated ) {
		_FVE_show();
		login_activated = false;
	}
   
}

function FVE_loaded() {
	if ( loader_interval_id ) {
		clearInterval( loader_interval_id );
		loader_interval_id = null;
	}	
}

function FVE_restart() {
    FVE_stop();    
    FVE_start();
}

function FVE_stop() {
	update_active = false;
    
    if ( data_update_timer_id !== null ) {
		
        // If there is an ongoing data interval update
        clearTimeout( data_update_timer_id );
		data_update_timer_id = null;
        log_info('Interval cleared due to stop');
    }	
}

function FVE_start() {
    
    // Initiate toolbar icon to inactive
    FVE_deactivated( true );
	
	// Connect to master DB
	master_db = new DB();
	
	// Check if there is an connection to the master database
	if ( !master_db.handle ) {
	
		// If not
		// Stop execution( the error is handled else where)		
		return false;
	}
	
	// else continue with initialization
	master_db.init( function() {
		
		// Get or create the install object for saving settings on this
		// installation of FVE
		new Install().save( function( installs ) {
			
			// Save it in memory
			current_install = installs[ 0 ];		
		} );
		
	} );
	
	// Get or create the account object related to a facebook account
	new Account().getLoginFromFB( -1, function( login ) {
		
		
		if ( login ) {
			
			log_info( "User login got:" + login.account.name );		
			
			// If login was found
			
			// Save it in memory
			current_login = login;			
							
			// Stop possible loading icon animation        
			FVE_loaded();
			
			// Set toolbar icon to active
			FVE_activated();
			
			// Reset last update time(where requests was updated)                                       
			duration_of_last_update = UPDATE_INTERVAL_SIZE;
			
			// Start update cycle
			FVE_update_cycle();
		} else {
			
			log_info( "User login not got" );		
			
			// If login was not found
			
			// Stop possible loading icon animation        
			FVE_loaded();
			
			// Show deactive-icon
            FVE_deactivated( false );				
		}
	} );
}

FVE_start();

function tabsOnUpdatedAddListener(){};
chrome.tabs.onUpdated.addListener( function( tabId, changeInfo, tab ){
	//log_info( 'onUpdated activated' );
	
	if ( app_tab && ( app_tab.id == tabId ) && ( changeInfo.url ) && ( !changeInfo.url.match( /^chrome-extension/ ) ) ) {
		
		app_tab = null;
		
		if ( !changeInfo.url.match( /^http:\/\/www\.facebook\.com\/login\.php/ ) ) {
			login_activated = false;	
		}
		
	} 
} )

// Listen to tab selection change
function tabsOnSelectionChangedAddListener(){};
chrome.tabs.onSelectionChanged.addListener( function( tabId, selectInfo) {
    //log_info( 'onSelectionChanged activated' );
	
	if ( app_tab != undefined ) {
        
        // If the app is open in window
        
        if ( ( app_tab.windowId === selectInfo.windowId ) && ( tabId === app_tab.id ) ) {
        
			
		
            // If it is this window and this tab
            
            // Ask content script to initiate update of info
            //chrome.tabs.sendRequest( tabId, { action: "updateInfo" } );
        }        
    }
    
} );

function recreate_db( callback ) {
	// Stop current data update
	FVE_stop();
		
	// Stop queue by emptieing it
	queued_requests = [];
	
	// Wait two seconds
	setTimeout( function() {
		
		// Clear master db
		var master_db = new DB();
		master_db.recreate( function() {
		
			// Clear database
			var db = new DB( '1001193790' ); // My account
			db.recreate( function() {
				
				db = new DB( '100001181011499' ); // Jimmy
				db.recreate( function() {
					
					db = new DB( '100001157341495' ); // Jack
					db.recreate( function() {
						
						// Close current app page
						if ( app_tab ) {
							chrome.tabs.remove(  app_tab.id );	
						}
						
						// Reload extension
						callback();
						window.location.reload();	
						
						
					} );
				} );
			})
		} );
	}, 2000 )
	
	
}

function finish_default_visual_request( tab_id, request_id, app_id, state, state_text, result_page_html ) {
	
	log_info( "Finishing default request:" + request_id );
	log_info( "Result page html:\n" + result_page_html );
	
	// Release tab
	queue_tabs[ tab_id ] = null;
	
	// Save request and do callback
	var request_obj = new Request();
	request_obj.id = request_id;
	request_obj.app_id = app_id;
	request_obj.state = state;
	request_obj.state_text = state_text;	
	request_obj.save( function( requests ) {		
		_request_processing_done( requests );
	} );	
}

function inject_default_content_scripts( tab_id, location ) {
	
	var queue_tab = queue_tabs[ tab_id ];
	
	// Check if this is a queue tab
	if ( queue_tab ) {
		
		// Check if the calling script is a valid result page
		var app_def = app_defs[ queue_tab.app_id ];
		
		var is_result_page = false;
		if ( app_def && app_def.functions && app_def.functions.is_result_page ) {
			is_result_page = app_def.functions.is_result_page( tab_id, queue_tab, location );
		}	
	
		if ( is_result_page ) {
			
			// Only inject default scripts into valid result page
			
			log_info('Injects default scripts into tab with id:' + tab_id + ' on location:' + location + ' for request with id:' +  queue_tab.request_id );	
			
			// Inject scripts
			chrome.tabs.executeScript( tab_id , { "file" : "/general/js/jquery/jquery-1.6.min.js" }, function() {
				chrome.tabs.executeScript( tab_id, { "file" : "/general/js/util.js" }, function() {
					chrome.tabs.executeScript( tab_id, { "file" : "/general/js/content.js" }, function() {
						log_info('Default scripts was injected into tab with id:' + tab_id );		
						
					});
				} );
			} );
		}
	}	
}

// Respond to requests from frontend script
chrome.extension.onRequest.addListener( function(request, sender, sendResponse) {
	
	//log_info( 'Request received: ' + request.action );
	
	
	if ( request.action == 'inject_default_content_scripts' ) {
		
		inject_default_content_scripts( sender.tab.id, request.location );
		sendResponse( true );	
		
	} else if ( request.action === 'get_tab_info' ) {
		
		log_info( "get_tab_info called from tab:" + sender.tab.id );
		
		var queue_tab = queue_tabs[ sender.tab.id ];
		
		if ( queue_tab ) {
		
			var app_def = app_defs[ queue_tab.app_id ];
			if ( app_def ) {
				var content_script;
				if ( app_def.content_script ) {
					content_script = app_def.content_script
				} else {
					
					content_script = "/games/" + app_def.name + '/definition.js';
				}
			
				log_info( "Injecting def. script into:" + sender.tab.id );
				chrome.tabs.executeScript( sender.tab.id, { file: content_script }, function() {
					log_info( "Injected def. script into:" + sender.tab.id );
					
					sendResponse( queue_tab );		
				});
			} else {
				sendResponse( queue_tab );	
			}
		} else {
			sendResponse( false );	
		}
		
	} else if ( request.action === 'finish_default_visual_request' ) {
		
		finish_default_visual_request( sender.tab.id, request.request_id, request.app_id, request.state, request.state_text, request.result_page_html );		
		sendResponse( true );
		
	} else if ( request.action === 'start_queue' ) {
		start_queue();
		sendResponse( true );
		
	} else if ( request.action === 'update_login_status' ) {
        
		// Update info about facebook user login
		
		log_info( 'update_login_status:' + request.location );
				
		new Account().getLoginFromFB( request.user_id, function( login ) {			
			if ( login ) {
				
				log_info( "User login got:" + login.account.name );		
			
				current_login = login;
				
				if ( login.just_logged_in ) {
					FVE_activated();	
				}
				
				if ( login.user_changed ) {
					
					// Temporary show the loading icon until new user is loaded                                        
					FVE_deactivated( true );
					
					// Open user database(initialize if necesary)
					current_user_db = new DB( login.account.id );
					
					if ( current_user_db.handle ) {
					
						current_user_db.init( function() {
							
							current_user_id = login.account.id;
							
							// When database it initialized								
							
							// Reset last update time(where requests was updated)                                       
							duration_of_last_update = UPDATE_INTERVAL_SIZE;
							
							FVE_activated();
							
							// Start update cycle
							FVE_update_cycle();
							
						});
					} else {
						
						// Only warn here. Error handled in DB.js
						log_warn( "Could not access user database on login" );
					}
				}
			} else {
			
				// If there is no user
			
				log_info( "User login not got" );		
				
				if ( update_active ) {
					log_warn("Update for last user is still active");
					abort_current_update = true
				}
				
				// Reset id saved in memory
				current_user_id = -1;
				
				// Set toolbar icon to deactive
				FVE_deactivated( false );
				
				if ( data_update_timer_id !== null ) {
					// If there is an ongoing data interval update
					
					// Stop the interval update until another user login
					clearTimeout( data_update_timer_id );
					data_update_timer_id = null;
					log_info('Interval cleared due to no user');
				}				
			}
		} );
            
       
		sendResponse( true );
    }
    
    
});


function _request_marked_in_UI( requests, result_state ) {
	if ( result_state ) {
		log_info( 'Marked the request:' + requests[ 0 ].id + ' as ' + result_state );
	}
	
	log_info( "Running processes:" + running_procs_count );
	log_info( "Queue length:" + queued_requests.length );
	log_info( "max_procs_count_sec:" + max_procs_count_sec );
	
	
	// If all tabs has been removed OR this is there is no running procs	
	if ( max_procs_count_sec == 0 || ( ( running_procs_count <= 1 ) && ( queued_requests.length == 0 ) ) ) {
	
		// If this is the last done proces and there are no more to process
		log_info("Queue is done");
		
		if ( app_tab ) {
			
			if ( max_procs_count_sec == 0 ){
				
				ask_for_abort_queue = true;				
				abort_reason = ABORT_RESERVED_WARNING;
				
				queued_requests = [];
				
				// Report finish of queue
				log_info("Report finish of queue due to closing of working tabs(2)");
				chrome.tabs.sendRequest( app_tab.id, { action: "queue_is_done", aborted : ask_for_abort_queue, abort_reason: abort_reason }, function() {
					
					// Decrease running process counter
					running_procs_count--;		
				} );
			
			} else {
			
				log_info("Report finish of queue due to no more request");
				// Report finish of queue
				chrome.tabs.sendRequest( app_tab.id, { action: "queue_is_done", aborted : ask_for_abort_queue, abort_reason: abort_reason }, function() {
					
					// Decrease running process counter
					running_procs_count--;			
				} );
			}		
			
		} else {
			log_warn("Could not find app tab");	
		}
	} else {
		// Decrease running process counter
		running_procs_count--;	
	}
	
}

function _request_processing_done( requests ) {
	
	var state_id = requests[ 0 ].state;
	var mark_request_as;
	if ( state_id == 3 ) {
		mark_request_as = 'done';
	} else if ( state_id > 4 ) {
		mark_request_as = 'error';
	}
	
	
	if ( app_tab ) {
		log_info( 'Marking the request:' + requests[ 0 ].id + ' as ' + mark_request_as );
			
		// Mark request 
		chrome.tabs.sendRequest(
			app_tab.id,
			{ action: "mark_request_as", uniqueId: requests[ 0 ].getUniqueId(), state: mark_request_as, state_text: requests[ 0 ].state_text  },
			function( result_state ) {
				_request_marked_in_UI( requests, result_state )
			}
		);	
	} else {
		log_warn("Could not find app tab");
		_request_marked_in_UI( requests, result_state );
	}
}

function add_procs() {
	
	log_info("Adding proces:(running: " + running_procs_count + ")")
	
	// Determine how many processes to start simultaneously
	var start_procs_count = max_procs_count_sec - running_procs_count;
	
	var request;
	for ( var i = 0; i < start_procs_count; i++ ) {
		
		if ( queued_requests.length > 0 ) {
			
			// Pick request from top of queue
			request = queued_requests[ 0 ];
			queued_requests.shift();
			
			// Increase running process counter
			running_procs_count++;
			
			if ( app_tab ) {
						
				// Mark request as running in UI
				chrome.tabs.sendRequest( app_tab.id, { action: "mark_request_as", uniqueId: request.getUniqueId(), state: "running" } );	
			} else {
				log_warn("Could not find app tab");	
			}
			
			log_info( 'Running request with id ' + request.id );
			
			request.proces( function( requests ) {
				
				_request_processing_done( requests );
			}, false );
		} 
	}
	
	if ( queued_requests.length > 0 ) {
		setTimeout( function() {
			add_procs( )
		}, 1000 );
	} 
}

function open_tabs_for_use( speed, callback ) {
	
	var tab_selected = false;
	if  ( speed == 1 ) {
		//tab_selected = true;
	}
	
	// Open a new tab
	chrome.tabs.create( { url: '/dialogs/main/html/reserved.html', selected: tab_selected }, function( tab ) {
		
		// Mark this tab ready for use in queue
		queue_tabs[ tab.id ] = null;
		
		// Check if more tabs need to be opened
		var keys = Object.keys( queue_tabs ).length
		if ( keys < max_procs_count_sec ) {
			
			// Open a new tab is room for more
			open_tabs_for_use( speed, callback );		
		
		} else {
		
			// Do callback if we got all tabs open
			callback();
		}
	} );
}

function start_queue( ) {
	log_info('Starting queue');
	
	// Reset tabs marked for use with queue
	queue_tabs = {};
	
	// Reset running processes
	running_procs_count = 0;
	
	current_login.account.load( function( account ) {
	
		log_info('Account info loaded for queue');
	
		// Reset max procs. count to default
		max_procs_count_sec = account.speed;
		
		log_info('max_procs_count_sec loaded:' + max_procs_count_sec );;
			
		// Open tabs
		open_tabs_for_use( account.speed, function() {		
				
			log_info('Tabs for use opened');
				
			// Start adding processes
			add_procs( );	
		})
	} );
	
}

function remove_processing_tabs() {
	for ( var tab_id in queue_tabs ) {
		delete queue_tabs[ tab_id ];
		chrome.tabs.remove( parseInt( tab_id ) );
	}	
}

function abort_queue( reason, callback ) {
	log_info('Aborting queue');
	ask_for_abort_queue = true;
	abort_reason = reason;
	
	// Remove requests from queue in DB
	log_info( 'All requests removed due to abort' );
		
	// Remove requests from queue in memory
	queued_requests = [];
		
	if ( callback ) callback();
	// Queue will now automatically stop when they is no more to queue	
	
		
	
}

function open_request_in_new_tab( app_url, callback ) {
	chrome.tabs.create( { url: app_url, selected: false }, callback );
}

function open_request_in_tab( tab_id, app_url, callback ) {
	chrome.tabs.update( parseInt( tab_id ), { url: app_url, selected: false }, callback );
}

chrome.tabs.onRemoved.addListener( function(  tabId, removeInfo ) {
	
	//log_info( 'onRemoved activated' );
	
	if ( app_tab && ( tabId == app_tab.id ) ) {
		
		app_tab = null;
		login_activated = false;
	} else {
		check_for_reserved_tab_change( tabId );				
	}
});

function abort_update() {
	
	if ( abort_current_update ) {
		abort_current_update = false;
		return true;
	} else {
		return false;
	}
	
}

function check_for_reserved_tab_change( tab_id ) {
	
	var aborted = false;
	var requests_to_abort = [];
	
	// Loop all tabs available for queue
	for ( var queue_tab_id in queue_tabs ) {
				
		// Check if one of them is trying to be removed
		if ( queue_tab_id == tab_id ) {
			
			log_info('Closure was critical of:' + tab_id + ' because it was identical to queue tab ' + queue_tab_id);
			// Id a possible request reserved for this tab
			var request;
			var tab_info = queue_tabs[ tab_id ];
			if ( tab_info != null ) {
				
				if ( tab_info.request_id && tab_info.app_id ) {
					
					request = new Request();
					request.id = tab_info.request_id;
					request.app_id = tab_info.app_id;
					
					
				}
			}
			
			// Remove the tab from the queue hash so it is not available for use any more
			delete queue_tabs[ tab_id ];
			
			// Decrease max proc count to fit the new number of tabs
			max_procs_count_sec--;			
			
			if ( request ) {
				log_info('With attached request:' + request.id  );
				log_info('Finishing the request' + request.id );
				
				// If request was id'ed
				
				// Finish the request with an error
				request.state = 6;
				request.state_text = 'Failed due to closing of working tab';
				
				request.save( function( requests ) {		
					_request_processing_done( requests );
				} );
				
			} else {
				
				log_info('Without attached request'  );
				if ( max_procs_count_sec == 0 ){
				
					// Finishing queue
				
					ask_for_abort_queue = true;				
					abort_reason = ABORT_RESERVED_WARNING;
				
					// Report finish of queue
					
					// Empty queue
					queued_requests = [];
					log_info("Report finish of queue due to closing of working tabs(1)");
					chrome.tabs.sendRequest( app_tab.id, { action: "queue_is_done", aborted : ask_for_abort_queue, abort_reason: abort_reason } );
				} 			
			}
			
		} 
	}	
}

function inform_UI_about_new_requests( new_request_count ) {
	
	if ( app_tab ) {		
		chrome.tabs.sendRequest( app_tab.id, { "action": "new_requests_update", "count" : new_request_count } );
	}	
}


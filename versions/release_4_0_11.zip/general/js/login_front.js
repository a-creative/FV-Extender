				
var script_html;
var script;
var user_id = false;
for ( var i = 0; i < document.scripts.length; i++ ) {
    script = document.scripts.item( i );
    script_html = script.innerHTML;
    if ( script_html ) {
        
        if ( script_html.indexOf( "Env={user:"  ) != -1 ) {
            
            var matches;
            if ( matches = script_html.match( /Env=\{user:(\d+)/ ) ) {
                user_id = matches[ 1 ];
                break;
            }
        }
    }					
}


// Don't detect logon changes made by zynga.com
if (
        ( window.location.href.indexOf( "zynga.com" ) == -1 )
) {
    
    chrome.extension.sendRequest( { action: "update_login_status", user_id : user_id, location: window.location.href } );
}
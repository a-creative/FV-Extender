function FVE_http_decode( http_url ) {
	var url = http_url.replace( '%3F', '?' );
	url = url.replace( /%3D/g, '=' );
	url = url.replace( /%26/g, '&' );
	url = url.replace( /%3A/g, ':' );
	url = url.replace( /%3A/g, ':' );
	url = url.replace( /%5B/g, '[' );
	url = url.replace( /%5D/g, ']' );
	url = url.replace( /%5C/g, '\\' );
	url = url.replace( /%2F/g, '/' );
	
	return url;
}

function blink( el ) {
	if (!el) {
		el = this
	}
	
	$(el).animate( { opacity: 0.5 },1200, function() {
		$(this).animate( {opacity: 1 }, 1200, blink );
	} );
}

function extractFacebookPagelets( baseHtml ) {
				
	// Find all pagelet content
	var pagelet_contents = baseHtml.match( /"content"\:\{"pagelet.*"}/g );
	
	var html_content_parts = '';
	var html_content_part;
	var pagelet_content;
	
	if ( pagelet_contents ) {
		// Loop pagelet contents
		for ( var i = 0; i < pagelet_contents.length; i++ ) {
			pagelet_content = pagelet_contents[ i ];
			
			
			
			// Extract html json content from pagelet content
			html_content_part = pagelet_content.replace( /^"content"\:\{"pagelet_[^"]+"\:"/, '' )
			html_content_part = html_content_part.replace( /"\}$/,'' );
			
			// Join html json content
			html_content_parts += html_content_part;
			
		}
	
	
		// Parse html json
		var json = '{ "html" : "' + html_content_parts + '" }';
		var obj = jQuery.parseJSON( json );
		var html = obj.html;
		
		// Prepare html for jquery object
		html = "<div>" + html + '</div>';
		
		return $( html );
	} else {
		return false;
	}
	
}

function sendData( type, url, data, success, error, extra_options ) {
	
	var post_options = {
		url : url,
		data : data,
		type: type,
		dataType: 'text',
		timeout: 10000
	};
	
	if ( extra_options ) {
		jQuery.extend( post_options, extra_options );
	}
		
	post_options.success = success;
	post_options.error = error;
	
	jQuery.ajax( post_options );	
}

function postData( url, data, success, error, extra_options ) {	
	sendData( 'post', url, data, success, error, extra_options );
}

function getData( url, data, success, error, extra_options ) {	
	sendData( 'get', url, data, success, error, extra_options );
}


function showWindow( options ) {
	
	var content = options.content;
	
	var width = options.width;
	var height = options.height;
	var left = options.left;
	var top = options.top;
	var buttons = options.buttons;
	
	var wnd = $('#window');
	
	wnd.find('.border, .position')
		.width( width + 44 )
		.height( height + 44 );
		
	// Position
	wnd
		.find('.position')
			.css('top',   '50%')
			.css('left',   '50%')
		.end()
		.find('.layers')
			.css('left', '-' + ( ( width + 44 ) / 2 ) + 'px')
			.css('top', '-' + ( ( height + 44 ) / 2 ) + 'px');
	
	// Add content
		wnd
			.find('.content')
				.html( content )
				.width( width )
				.height( height );
	
	
	// Display
	$('#window').fadeIn();	
}

function hideWindow() {
	$('#window').fadeOut();	
}
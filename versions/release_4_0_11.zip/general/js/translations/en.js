GLOBAL_transl.en = {    
    'ERR_LOADING_REQUESTS'  : 'Error on loading requests',
    'INFO_LOAD_ERR_TEXT'    :  'Info text could not be loaded from server.',
    'INFO_HEADLINE'         :  'Info',
    'INFO_LOAD_ERR_HEADLINE':  'Error',
	'MONTHS'					: [
		'January',
		'February',
		'March',
		'April',
		'May',
		'June',
		'July',
		'August',
		'September',
		'October',
		'November',
		'December'		
	]
}
var FVE_log_lines = [];

function log( type, message ) {
	
	var line = {
		"type" : type,
		"time" : new Date().getTime(),
		"message" : message
	};
	
	FVE_log_lines.push( line );
	
	console.log( log_line_to_string( line ) );
}

function log_line_to_string( line ) {
	return (
			new Date( line.time ).toLocaleString() + "\t" 
			+	line.type + "\t"
			+	line.message + "\n"
	);
}

function log_info( message ) {
	log ( 'i', message );
}

function log_warn( message ) {
	log ( 'w', message );
}

function log_error( message ) {
	log ( 'e', message );
}

function get_log() {
	var output = '';
	var line;
	for ( var i = 0; i < FVE_log_lines.length; i++ ) {
		line = FVE_log_lines[ i ];
		output += log_line_to_string( line );			
	}
	
	return output;
}


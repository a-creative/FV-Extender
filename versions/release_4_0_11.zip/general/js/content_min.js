// This script is run when all html is load(but not necesarily rendered)

// Ask background page to inject scripts




chrome.extension.sendRequest( { action: "inject_default_content_scripts", location: window.location.href } );

console.log( 'Content min loaded' );
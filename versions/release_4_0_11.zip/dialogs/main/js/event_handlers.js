
function accept_reject_request_manually( el, action ) {
	
	// Start by changing process requests button to "Update"
	var btn = $('#process-requests-btn');
	if ( btn && ( btn.html() != 'Update request list' ) ) {
		btn.html('Update request list');
		btn.unbind('click' );
		btn.bind('click', _updateRequestListClicked )
	}
	
	var request_group_el = $(el).closest('.group');
	
	request_group_el
		.find('.status-icon')
		.attr('class', 'status-icon ' + action + ' running' )
		.children().first().attr( 'title', 'Request is being manually ' + action + 'ed' );
		
	var request_el = request_group_el.find('.individual-requests > div').first();
	
	var request_id = request_el.attr( 'request_id' );
	var app_id = request_el.attr( 'app_id' );
	
	var request = bgp.FVE_RequestClass();
	request.id = request_id;
	
	request.app_id = app_id;
	request.action = action;
	
	request.proces(
		function( requests, app_url ) {
			var request = requests[ 0 ];
			
			
			if ( request.state > 4 ) {
				mark_request_as( request.getUniqueId(), 'error', '', null, true );
			} else if ( request.action == 'accept' ) {
				
				bgp.open_request_in_new_tab( app_url, function() {
					
					request.state = 3;
					bgp.current_user_db.saveRequests( [ request ], function() {
						mark_request_as( request.getUniqueId(), 'done', '', null, true );
					} );
					
				});
								
			} else {
				request.state = 3;
				bgp.current_user_db.saveRequests( [ request ], function() {
					mark_request_as( request.getUniqueId(), 'done', '', null, true );
				} );
			}
		
		},
		true // Manual run
	)
	
}

function _accept_manual_click( evt ) {
	accept_reject_request_manually( this, 'accept' );
	evt.preventDefault();
}

function _reject_manual_click( evt ) {
	accept_reject_request_manually( this, 'reject' );
	evt.preventDefault();
}

function _accept_ided_click( evt ) {
	var request_group_el = $(this).closest('.group');
	
	// Tag request group to be accepted
	request_group_el
		.find('.status-icon')
		.attr('class', 'status-icon accept')
		.children().first().attr( 'title', 'Request is marked to be accepted' );
	
	// Activaate reject button
	var reject_span = request_group_el.find('.auto-ided span.reject');
	var span_txt = reject_span.html(); 	
	var reject_btn = $('<a href="#" class="reject">' + span_txt + '</a>');
	reject_btn.click( _reject_ided_click );
	reject_span.replaceWith( reject_btn );
	
	// Dectivate accept button
	var accept_btn = request_group_el.find('.auto-ided a.accept')
	var btn_txt = accept_btn.html(); 	
	var accept_span = $('<span class="accept">' + btn_txt + '</span>')
	accept_btn.replaceWith( accept_span );
	
	// Save with default setting
	save_item_default_action( request_group_el, function() {});	
	
	evt.preventDefault();
	
}

function save_item_default_action( request_group_el, callback ) {
	
	// Get item id
	var item_id = request_group_el.prop( 'item_id' );
		
	// Get app id
	var app_id = request_group_el.closest('.app').prop('app_id');
	
	// Get default status
	var is_default = request_group_el.find('.do-always input').prop('checked');
		
	// Get action
	var action = '';
	if ( request_group_el.find('.status-icon').hasClass('reject') ) {
		action = 'reject'
	} else {
		action = 'accept';
	}
	
	var default_action = '';
	if ( is_default ) {		
		default_action = action;
	} 
	
	var item = bgp.FVE_ItemClass();
	item.id = item_id;
	item.app_id = app_id;
	item.default_action = default_action;
	item.save( function() {} );		
}

function _do_always_request_action_changed( evt ) {
	save_item_default_action( $(this).closest( '.group' ), function() {});
}

function _reject_ided_click( evt ) {
	var request_group_el = $(this).closest('.group');
	
	// Tag request group to be rejectd
	request_group_el
		.find('.status-icon')
		.attr('class', 'status-icon reject')
		.children().first().attr( 'title', 'Request is marked to be rejected' );
	
	// Deactive reject button
	var reject_btn = request_group_el.find('.auto-ided a.reject')
	var btn_txt = reject_btn.html(); 	
	var reject_span = $('<span class="reject">' + btn_txt + '</span>')
	reject_btn.replaceWith( reject_span );
	
	// Activate accept button
	var accept_span = request_group_el.find('.auto-ided span.accept');
	var span_txt = accept_span.html(); 	
	var accept_btn = $('<a href="#" class="accept">' + span_txt + '</a>');
	accept_btn.click( _accept_ided_click );
	accept_span.replaceWith( accept_btn );
	
	// Save with default setting
	save_item_default_action( request_group_el, function() {
	
	} );
	
	evt.preventDefault();	
}

function _accept_click( evt ) {
	var request_group_el = $(this).closest('.group');
	
	// Tag request group to be accepted
	request_group_el
		.find('.status-icon')
		.attr('class', 'status-icon accept')
		.children().first().attr( 'title', 'Request is marked to be accepted' );
	
	// Activaate reject button
	var reject_span = request_group_el.find('.auto span.reject');
	var span_txt = reject_span.html(); 	
	var reject_btn = $('<a href="#" class="reject">' + span_txt + '</a>');
	reject_btn.click( _reject_click );
	reject_span.replaceWith( reject_btn );
	
	// Dectivate accept button
	var accept_btn = request_group_el.find('.auto a.accept')
	var btn_txt = accept_btn.html(); 	
	var accept_span = $('<span class="accept">' + btn_txt + '</span>')
	accept_btn.replaceWith( accept_span );
	evt.preventDefault();
	
}

function _reject_click( evt ) {
	
	var request_group_el = $(this).closest('.group');
	
	// Tag request group to be rejected
	request_group_el
		.find('.status-icon')
		.attr('class', 'status-icon reject')
		.children().first().attr( 'title', 'Request is marked to be rejected' );
	
	// Deactive reject button
	var reject_btn = request_group_el.find('.auto a.reject')
	var btn_txt = reject_btn.html(); 	
	var reject_span = $('<span class="reject">' + btn_txt + '</span>')
	reject_btn.replaceWith( reject_span );
	
	// Activate accept button
	var accept_span = request_group_el.find('.auto span.accept');
	var span_txt = accept_span.html(); 	
	var accept_btn = $('<a href="#" class="accept">' + span_txt + '</a>');
	accept_btn.click( _accept_click );
	accept_span.replaceWith( accept_btn );
	
	evt.preventDefault();	
}

function insert_request_element_el( request, current_group_el, last_item_name, manually_accept ) {
	if (
			( last_item_name != request.item_name )
		||	(
					( !request.item_id )
				 &&	( !request.app_def )
			)
		||	( manually_accept )
	) {
		
		// If previous added request had a different item_id
		// or there is not item_id and app. definition.
		// Or app is marked for manual acceptance
		
		// Finish the current group before creating a new one
		if ( current_group_el && (! ( $(current_group_el).hasClass( 'single-request' ) ) ) ) {
			
			// If the current group is not one with a a single request
			
			// Fill out "number of requests" within this request group
			var count = current_group_el.find( '.request' ).length;
			current_group_el.find('.count span').html( count );
		}
		
		// Create a new group from a template
		request_group_el = jQuery('#request-list-item-template').clone();
		current_group_el = request_group_el;
		request_group_el.removeClass('template');
		
		// Give the new group a random id
		var rnd_id = Math.floor( ( Math.random() * 100) ) + 1;
		request_group_el.prop( 'id' , 'request-group-' + rnd_id + '_' + Math.floor( new Date().getTime() / 1000 ) );
		
		if (
					( !manually_accept )
				&&	(
						( request.item_name )
					||	( ( !request.item_name ) && ( request.app_def ) )					
				)
		) {
			
			// If the request has an item name
			// or no item name and a app. definition
			// and is not marked by user to be forced for manually acceptance
			
			var name_el = request_group_el.find('.name');
			if ( request.item_name) {
				
				// If request has an item name
				
				// use the item name as the group name
				name_el.html( request.item_name );
				
				// Mark the group with the default action
				request.getDefaultAction( function( request, action ) {
					
					var request_el = jQuery('.individual-requests .request[unique_id=' + request.getUniqueId() + ']');
					var request_group = request_el.closest('.group');
					
					var icon_class = 'status-icon';
					if ( action == 'reject' ) {
						icon_class += ' ' + action;
						
						$(request_group)
							.find( '.auto-ided a.reject' )
								.replaceWith( '<span class="reject">Reject</span>' )
							.end()
							.find( '.auto-ided .do-always input' )
								.prop( 'checked', true )
							.end()
							.find( '.auto-ided a.accept' )
								.click( _accept_ided_click );
						
					} else {
						icon_class += ' accept';
						
						var do_always = false;
						if ( action == 'accept' ) {
							do_always = true;	
						} 
						
						$(request_group)
							.find('.auto-ided a.accept')
								.replaceWith('<span class="accept">Accept</span>')
							.end()
							.find( '.auto-ided .do-always input' )
								.prop( 'checked', do_always )
							.end()
							.find( '.auto-ided a.reject' )
								.click( _reject_ided_click );
					} 
					
					$(request_group).find( '.auto-ided .do-always input' ).change( _do_always_request_action_changed );
					
					$(request_group)
						.find('.actions .manually')
							.hide()
						.end()
						.find('.actions .auto')
							.hide()
						.end()
						.find('.actions .auto-ided')
							.show()
						.end();
					
					request_group
						.find( '.status-icon' )
							.removeClass()
							.addClass( 'status-icon ' + icon_class )
							.children().first().attr( 'title', 'Request is marked to be ' + icon_class + 'ed' );
							
				
				} );								
				
			} else {
				
				// If request has no item name
				
				// Mark it as an request for help and name it
				name_el.html( 'Requests for help' );
				
				request_group_el.find('.status-icon')
					.addClass( 'accept' )
					.children().first().attr( 'title', 'Request is marked to be accepted' );
				request_group_el.find('.actions').hide();
				
			}
			
			// Show the name of the group
			name_el.css('display','block');
			
		} else {
				var desc_el = request_group_el.find('.description');
				desc_el.html( request.text );
				desc_el.css('display','block');
				
				$(request_group_el).addClass( 'single-request' );
				request_group_el.find('.status-icon')
					.addClass( 'accept' )
					.children().first().attr( 'title', 'Request is marked to be accepted' );
				
				if ( manually_accept ) {
	
					// Show active "reject" and "Accept" buttons at each request for this app
					$(request_group_el)
						.find('.actions .manually')
							.show()
							.find('.accept')
								.click( _accept_manual_click )
							.end()
							.find('.reject')
								.click( _reject_manual_click )
							.end()
						.end()
						.find('.actions .auto')
							.hide()
						.end()
						.find('.actions .auto-ided')
							.hide()
						.end()
						.find('.status-icon')
							.attr('class', 'status-icon manually')
							.children().first().attr( 'title', 'Request is marked to be processed manually' )
						.end();
						
							
				} else {
					$(request_group_el)
						.find('.actions .manually')
							.hide()
						.end()
						.find('.actions .auto')
							.show()
						.end()
						.find('.actions .auto-ided')
							.hide()
						.end()
						.find( '.auto a.reject' )
								.click( _reject_click )
						.end()
						.find('.status-icon')
							.attr('class', 'status-icon accept')
							.children().first().attr( 'title', 'Request is marked to be accepted' )
						.end();
				}
		}
		
		var image_el = request_group_el.find('.image img');
		image_el.prop( 'src', request.getItemImageUrl() );									
		
		var app_el = $('#app-' + request.app_id );
		if ( app_el.length ) {
			app_el.find('.requests').append( request_group_el );
		} 
	}
	
	var unique_req_id =  request.getUniqueId();
	
	var request_class = "request ready";
	if ( manually_accept ) {
		request_class += " manually";
	}
	
	current_group_el.find('.individual-requests').append( '<div class="' + request_class + '" id="request-' + unique_req_id + '" unique_id="' + unique_req_id +'" request_id="' + request.id + '" app_id="' + request.app_id + '"></div>' );
	
	last_item_name = request.item_name;
	
	return ( { current_group_el: current_group_el, last_item_name: last_item_name } );
}

function insert_request_elements( requests, manually_accept ) {
	var request;
	var last_item_name = -1;
	var current_group_el;
	var result;
	
	for ( var j = 0; j < requests.length; j++ ) {
		request = requests[ j ];
		
		result = insert_request_element_el( request, current_group_el, last_item_name, manually_accept );
		
		current_group_el = result.current_group_el;
		last_item_name = result.last_item_name;
		
		
	}
	
	if ( current_group_el && (! ( $(current_group_el).hasClass( 'single-request' ) ) ) ) {
		var count = current_group_el.find( '.request' ).length;
		current_group_el.find('.count span').html( count );
	}	
}

function _manually_accept_onChange( evt ) {
	
	var checkbox_el = $(this);
	
	var app_id = $(this).prop('app_id');
	
	var new_settings = $(this).prop( 'checked' );
	
	var app_settings = bgp.FVE_AppSettingsClass();
	app_settings.id = app_id;
	app_settings.manuallyAccept = $(this).prop( 'checked' );
	
	// Save setting in DB
	app_settings.save( function( app_settings_array ) {
	
		app_settings = app_settings_array[ 0 ];
		
		// When saved
		
		// Update request list
		if ( checkbox_el.prop( 'supports_grouping' ) ) {
			
			// If grouping of requests is supported
			
			// Update list of requests instead of transforming them
			update_request_els( false );
			
		} else {					
			
			// If grouping of requests is not supported
			
			// Just transform requests
			
			if ( app_settings.manuallyAccept ) {
				// Show active "reject" and "Accept" buttons at each request for this app
				var app_el = $( '#app-' + app_id );
				
				app_el
					.find('.actions .manually')
						.show()
					.end()
					.find('.actions .auto')
						.hide()
					.end()
					.find('.actions .auto-ided')
						.hide()
					.end()
					.find('.status-icon')
						.attr('class', 'status-icon manually')
					.end()
					.find('.status-icon a')
						.attr( 'title', 'Request is marked to be processed manually' )
					.end()
					.find('.request')
						.removeClass( 'manually' )
						.addClass( 'manually' )
					.end();
						
			} else {
				$( '#app-' + app_id )
					.find('.actions .manually')
						.hide()
					.end()
					.find('.actions .auto')
						.show()
					.end()
					.find('.actions .auto-ided')
						.hide()
					.end()			
					.find('.status-icon')
						.attr('class', 'status-icon accept')
					.end()
					.find('.status-icon a')
						.attr( 'title', 'Request is marked to be accepted' )
					.end()
					.find('.request')
						.removeClass( 'manually' )
					.end();
					
				$( '#app-' + app_id ).find('.auto a.reject').click( _reject_click );	
			}
		}
	} );
};

function insert_app_and_request_elements( appSettingsHash, apps ) {
	var cont_el = $('#requests');
		
	var app;
	var app_el;
	var request_group_el;
	var app_def;
	var app_settings;
	for ( var i = 0; i < apps.length; i++ ) {
		app = apps[ i ];
		
		app_settings = appSettingsHash[ app.id ];
		
		app_el = jQuery('#app-list-item-template').clone();
		app_el.prop( 'id', 'app-' + app.id );
		app_el.prop( 'app_id', app.id );
		app_el.find('.app-headline .name').html( app.name );
		cont_el.append( app_el );
		
		/* init. manually accept checkbox */
		var manual_acc_el = app_el.find('.manual-accept-check-box');
		
		var manual_acc_input_el = manual_acc_el.find( 'input' );
		
		manual_acc_input_el.prop( 'app_id', app.id );
		
		var supports_grouping = false;
		
		if ( app.def ) {
			if ( app.def.functions ) {
				
				if ( ( app.def.functions.get_item_id != null ) && ( app.def.functions.get_item_name != null ) ) {
					
					supports_grouping = true;
				}
			}
		}		
		
		manual_acc_input_el.prop( 'supports_grouping', supports_grouping );				
		
		manual_acc_input_el.change( _manually_accept_onChange );
		
		var accept_override;
		if ( ( !app_settings ) || ( app_settings.manuallyAccept === undefined ) ) {
			if ( app.def && ( app.def.accept_support == 'auto' ) ) {
				manual_acc_input_el.prop( 'checked', false );
				//manual_acc_el.hide();
			} else {
				manual_acc_input_el.prop( 'checked', true );
			}
		} else {
			manual_acc_input_el.prop( 'checked', ( app_settings.manuallyAccept == "false" ? false : true ) );
		}
		
		bgp.FVE_RequestClass().getReadyOrderedByItemIdFromAppId( app.id,  function( requests, app_id ) {
			
			var app_el = $('#app-' + app_id);
			var manually_accept = app_el.find('.manual-accept-check-box input').prop( 'checked' );
						
			insert_request_elements( requests, manually_accept );
		});
		
		app_el.removeClass('template');
	}	
}

function _userSettingsSaveClicked( evt ) {
	var account = bgp.current_login.account;
	
	var ok = true;
	
	var val = $("#user-settings .return-gift-text textarea").val();
	
	if ( val == "" ) {
		val = "NONE";
	} 
	
	account.return_gift_text = val;
	
	// Validate speed
		var speed_val = $('input:radio[name="speed"]:checked').val();
		if ( speed_val == 'x' ) {
			speed_val = $('#speed-var').val();
		
			if ( !speed_val.match( /^\d+$/ ) ) {
				alert( 'Please enter a valid number when setting the processing speed.');
				ok = false;
			} else {
				account.speed = speed_val;
			}
		} else {
			account.speed = speed_val;
		}
	
	if ( ok ) {
		account.save( function() {
			$("#user-settings").fadeOut();	
		});
	}
	
	evt.preventDefault();
}

function _userSettingsCancelClicked( evt ) {
	$("#user-settings").fadeOut();
	evt.preventDefault();
}

function dialog_height( dialog, height ) {	
	dialog
		.find('.content').height( height ).end()
		.find('.position, .border').height( height + 44 ).end();	
}

function _userSettingsClicked( evt ) {
	
	var account = bgp.current_login.account;
	
	// Load account settings
	account.load( function( account ) {
		
		var base_height = 205;
		
		// Check I this is the first time opening user settings
		if ( account.return_gift_text && ( evt !== true ) ) {
			
			dialog_height( $("#user-settings"), 21 + base_height );
			
			// Show default header
			$("#user-settings .header.welcome").css("display","none");
			$("#user-settings .header.default").css("display","block");
			
			// Initialize with default return gift text
			
			var val = account.return_gift_text;
			if ( val == "NONE" ) {
				val = "";
			}
			
			$("#user-settings .return-gift-text textarea").val( val );
			$('#user-settings').fadeIn();
		} else if ( !account.return_gift_text ) {
			
			dialog_height( $("#user-settings"), 98 + base_height );
			
			// Show welcome text
			$("#user-settings .header.welcome").css("display","block");
			$("#user-settings .header.default").css("display","none");
			
			// Initialize with saved text			
			$("#user-settings .return-gift-text textarea").val( bgp.DEFAULT_RETURN_GIFT_TEXT );
			$('#user-settings').fadeIn();
		}
		
		// Initialize speed
			if ( !account.speed ) {
				account.speed = 2;	
			}
			if ( ( account.speed < 3 ) && ( account.speed > 0 ) ) {
				$('#user-settings input:radio[name="speed"]').filter('[value="' + account.speed + '"]').attr('checked', true);
			} else {
				
				$('#speed-var').val( account.speed )
				
				$('#user-settings input:radio[name="speed"]').filter('[value="x"]').attr('checked', true);
			}
				
	} );
	
	if ( evt !== true ) {
		evt.preventDefault();
	}
}


function _abortRequestProcessingClicked( evt ) {
	
	// Request backend for stopping of queue
	$("#total-status-bar .counter").html( 'Aborting queue. Please wait...' );
	bgp.abort_queue();	
}

function _updateRequestListClicked( evt ) {
	
	// Activate check for new blog posts
	check_for_blog_updates();
	
	// Disable button until update is done
	var btn = $('#process-requests-btn');
	btn.unbind('click');
	
	// Remove tabs used for processing
	bgp.remove_processing_tabs();
	
	// Hide status bar and prepare it for next show
	$("#total-status-bar").css('display', 'none' )
	$("#total-status-bar .success").css( 'width', '0px' );
	$("#total-status-bar .error").css( 'width', '0px' );
	$("#total-status-bar .counter").html('');
	
	update_request_els( true );	
}

function update_request_els( defaultUpdate ) {
	
	if ( defaultUpdate ) {
		$('#blog-updates-pop-down').slideUp();
	}
	
	// Remove all apps that is not template
	$('#requests .app:not(.template)').remove();
	
	// Update request
	bgp.FVE_AppSettingsClass().getAllHash( function( appSettingsHash) {
					
		update_requests( appSettingsHash, false, function() {
			
			$('#updating-requests-info').remove();
			if ( $('#requests .app:not(.template)').length == 0 ) {
				$('#requests').append('<div id="updating-requests-info" class="text">No pending requests.</div>');
			} 
			
			if ( defaultUpdate ) {
				
				// If activated by clicking on "Update"
				
				// Change update button to process button
				var btn = $('#process-requests-btn');
				
				if ( btn ) {
					btn.html('Process requests');
					btn.unbind('click', _updateRequestListClicked );
					btn.bind('click', _processRequestsClicked );
				}
			}
		});	
	} );
}

function queue_requests( request_el, queue_for, callback ) {
	if ( !request_el.length ) {
		if ( callback ) {
			callback();
		} else {
			console.log( '7:Missing callback' );
		}
		return;
	}
	
	var request = bgp.FVE_RequestClass();
	request.id = $(request_el).attr( 'request_id' );
	request.app_id = $(request_el).attr( 'app_id' );
	request.action = queue_for;
	
	// Add request to queue in memory
	bgp.queued_requests.push( request );
	
	// Add next request to queue in memory
	var next_request_el = request_el.next();
	if ( next_request_el.length ) {
		queue_requests( next_request_el, queue_for, callback );
	} else {
		if ( callback ) {
			callback();
		} else {
			console.log( '8:Missing callback' );
		}
	}
}

function queue_groups( request_group_el, callback ) {
	if ( !request_group_el.length ) {
		if ( callback ) {
			callback();
		} else {
			console.log( '6:Missing callback' );
		}
		return;
	} 
	
	var status = request_group_el.find('.status-icon');
	var queue_for;
	if ( status.hasClass( "accept" ) ) {
		queue_for = "accept";				
	} else if ( status.hasClass( "reject") ) {
		queue_for = "reject"	
	}
	
	if ( queue_for ) {
		var requests_els = $(request_group_el).find('.request');		
		queue_requests( requests_els.first(), queue_for, function() {
			
			var next_request_group_el = request_group_el.next();
			
			if ( next_request_group_el.length ) {			
				
				queue_groups( next_request_group_el, callback );
			} else {
				if ( callback ) {
					callback();
				} else {
					console.log( '2:Missing callback' );
				}
			}
		});
	} else {
		
		var next_request_group_el = request_group_el.next();
		
		if ( next_request_group_el.length ) {
			queue_groups( next_request_group_el, callback );
		} else {
			if ( callback ) {
				callback();
			} else {
				console.log( '1:Missing callback' );
			}
		}
	}
}

function queue_app_next( next_app_el, callback ) {
	
	
	if ( next_app_el.length && ( next_app_el.prop( 'process_manually') != 'true' ) ) {
		queue_app_requests( next_app_el, callback );
	} else {
		if ( callback ) {
			callback();
		} else {
			console.log( '4:Missing callback' );
		}
	}	
}

function queue_app_requests( app_el, callback ) {
	if ( !app_el.length ) {
		if ( callback ) {
			callback();
		} else {
			console.log( '3:Missing callback' );
		}		
		return;
	}
	
	// Check if app is marked to "Proces manually"
	var manual_acc_input_el = app_el.find('.manual-accept-check-box input');
	var next_app_el = app_el.next();
	
	app_el.prop( 'process_manually', 'false' );
	if ( manual_acc_input_el.prop( 'checked' ) ) {
		
		app_el.prop( 'process_manually', 'true' );
	
		// Move app to bottom of parent
		var container = app_el.parent();
		app_el = app_el.detach();						
		container.append( app_el );
						
		// Goto next app
		queue_app_next( next_app_el, callback );		
		
	} else {	
		
		// Queue request groups in app	
		queue_groups( app_el.find('.group').first(), function() {
		
			// Goto next app
			queue_app_next( next_app_el, callback );
		
		} )
	}
}

function _aknUpdateAndBlogBtnClicked( evt ) {
	akn_update( evt, true );
	
}

function _aknUpdateBtnClicked( evt ) {
	akn_update( evt, false );
}

function akn_update ( evt, show_blog ) {
	
	// Save current timestamp to master db
	var install = bgp.FVE_InstallClass();
	install.last_info_update = new Date().getTime();
	install.save( function( installs ) {
		$('#blog-updates-pop-down').slideUp();	
		if ( show_blog ) {
			
			window.open( 'http://a-creative.dk', '_blank' );	
			
		} 	
	} );
	
	evt.preventDefault();
}

function show_blog_updates_pop_down( result ) {
	
	var post_els = $(result).find('post');
	if ( post_els.length ) {
	
		// Play sound
		document.getElementById('show-blog-update-snd').play();
		
		// Loop posts
		var headline;
		var timestamp;
		var posts_parts = [];
		post_els.each(function(){
			headline = $(this).find( 'headline' ).text();
			timestamp_sec = $(this).find( 'timestamp_sec' ).text();
			
			// Convert timestamp to local string
			var time_str = unixTimestampToStr( timestamp_sec );
			
			posts_parts.push( time_str + ' - ' + headline );
		});
		
		
		$('#blog-updates-pop-down .posts').html( posts_parts.reverse().join( '<br />' ) );
		
		$('#blog-updates-pop-down .read-more').show();
		
		// Show pop down
		
		$('#blog-updates-pop-down').slideDown();
	} 
}

function check_for_blog_updates() {
	
	// Load install info
	bgp.current_install.load( function( install ) {
		
		// Load blog updates
		
		// Request server
		getData( 'http://a-creative.dk/wp/getLatestPostsInfo.php', { "timestamp_ms" : install.last_info_update },
			function( result, textStatus, jqXHR ) {
				
				// On success
				// Inform the timout that we're actually done
				show_blog_updates_pop_down( result );
			},
			function ( jqXHR, textStatus, err ) {
				// Play sound
				document.getElementById('show-blog-update-snd').play();
				
				if ( err == 'timeout' ) {
					$('#blog-updates-pop-down .posts').html( 'Could not check for new blog posts due to server timout. Trying again later.' );
				} else {
					$('#blog-updates-pop-down .posts').html( 'Could not check for new blog posts. Please report this to stay updated. (code:' + err + ')' );
				}
				
				$('#blog-updates-pop-down .read-more').hide();
				$('#blog-updates-pop-down').slideDown();
			},
			{ cache: false, dataType: "xml", timeout: 3000 }
	
		);	
	} );
	
}

function _processRequestsClicked( evt ) {
	
	
	
	// Check if there is requests to process
	if ( $( '.status-icon.accept, .status-icon.reject' ).length ) {
	
		// Change button to "Abort" button
		$(this).html('Abort');
		$(this).unbind('click', _processRequestsClicked );
		$(this).bind('click', _abortRequestProcessingClicked )
		
		var apps = $('#requests .app:not(.template)');
		
		// Show status bar
		$('#total-status-bar').css( 'display', 'block' );
		$('#total-status-bar .counter').html( 'Saving queue. Please wait...' );
		
		queue_app_requests( apps.first(), function() {
			update_status_bar();
					
			chrome.extension.sendRequest( { action: "start_queue" } );
		
		})
	} else if ( $( '.status-icon.manually' ).length ) {
		alert( 'There are not any requests left to process automatically.\nThe rest is marked for manually processing.\nUncheck "Process manually" below a game title to accept the games\' requests automatically in the future.' );
	} else {
		alert( 'There are not any requests to process!' );
	}
	
	
	
	evt.preventDefault();	

}

function update_status_bar() {
	
	var all_requests = $( '.individual-requests .request' ).length;	
	
	var error_requests = $( '.individual-requests .error' ).length;
	var done_requests = $( '.individual-requests .done' ).length - error_requests;
	
	
	var manual_requests = $( '.individual-requests .manually' ).length;
	var all_auto_requests = all_requests - manual_requests;
	
	var pct_done = ( done_requests * 100 ) / all_auto_requests;
	var pct_error = ( error_requests * 100 ) / all_auto_requests;
	
	$("#total-status-bar .success").css( 'width', pct_done + '%' );
	$("#total-status-bar .error").css( 'width', pct_error + '%' );
	
	if ( !bgp.ask_for_abort_queue ) {
		$("#total-status-bar .counter").html( 'Processing requests: ' + ( done_requests + error_requests ) + ' of ' + all_auto_requests );
	}
	
	
}

function mark_request_as( requestUniqueId, state, state_text, callback, manually ) {
	
	console.log( 'text:' + state +', ' + state_text );
	
	if ( requestUniqueId == '101539264719_8936789' )
		console.log( 'Should group for request with id ' + requestUniqueId + ' be marked as ' + state + '?' );
	
	// Find request element
	var request_el = $('#request-' + requestUniqueId );	
	if ( request_el && request_el.length ) {
		
		if ( requestUniqueId == '101539264719_8936789' )
			console.log( '(1)Should group for request with id ' + requestUniqueId + ' be marked as ' + state + '?' );	
		
		//bgp.syslog( 'UI: Yes, the request was found' + requestUniqueId );
		
		// Find request group element
		var request_group_el = request_el.closest( '.group' );
		if ( request_group_el && request_group_el.length ) {
		
			if ( requestUniqueId == '101539264719_8936789' )
				console.log( '(2)Should group for request with id ' + requestUniqueId + ' be marked as ' + state + '?' );
		
			//bgp.syslog( 'UI: Yes, the group was found' + requestUniqueId );
		
			// Find status icon
			var status_el = request_group_el.find('.status-icon');
			
			if ( status_el && status_el.length ) {
				
				if ( requestUniqueId == '101539264719_8936789' )
					console.log( '(3)Should group for request with id ' + requestUniqueId + ' be marked as ' + state + '?' );
				
				var action;
				if ( status_el.hasClass( 'reject' ) ) {
					action = "reject";	
				} else if ( status_el.hasClass( 'accept' ) ) {
					action = "accept";
				}
			
			
				if ( requestUniqueId == '101539264719_8936789' )
					console.log( '(4)Should group for request with id ' + requestUniqueId + ' be marked as ' + state + '?' );
				
				if ( requestUniqueId == '101539264719_8936789' )
					console.log( '(5)Should group for request with id ' + requestUniqueId + ' be marked as ' + state + '?' +  status_el.attr('class') );
				
				
				if ( ( state == 'running' ) && ( !status_el.hasClass( state ) ) ) {
					if ( requestUniqueId == '101539264719_8936789' )
						console.log( '(4a)Should group for request with id ' + requestUniqueId + ' be marked as ' + state + '?' );

					
					request_el.attr('class','request running');
					
					status_el.removeClass( 'ready' );
					
					status_el.addClass( state );										
					
					status_el.children().first().attr( 'title','Request is being ' + action +'ed' );
					
					if (callback) callback( request_el );
				} else if ( ( ( state == 'done' ) || ( state == 'error' ) ) && ( !status_el.hasClass( state ) ) ) {
					
					if ( requestUniqueId == '101539264719_8936789' )
						console.log( '(4b)Should group for request with id ' + requestUniqueId + ' be marked as ' + state + '?' );
					
					// Mark the request as done or done with errors
					if ( state == 'error' ) {
						request_el.attr('class','request done error');
					} else {
						request_el.attr('class','request done');
					}
					
					// Set state text
					request_el.attr( 'state_text', state_text );
										
					// Update status bar for complete process
					update_status_bar();
					
					// Check if all requests below group are done(not ready)
					var not_done_requests = request_group_el.find( '.individual-requests :not(.done)' );
					
					if ( not_done_requests.length == 0 ) {
						var total_req_count = request_group_el.find( '.individual-requests .done' ).length;
						request_group_el.find('.count span')
							.html( total_req_count )
							.css( 'color', '#bfbfbf' );
					} else {
						request_group_el.find('.count span').html( not_done_requests.length );
					}
					
					// Check if this is the only request that is not done
					if ( not_done_requests.length == 0 ) {
						
						// If this is the only request not marked as done
						
						// If group is done
						status_el.removeClass( 'running' );
						
						// Check if any of the request are has error
						var error_requests = request_group_el.find( '.individual-requests .error' );
						if ( error_requests.length ) {
							status_el.addClass( 'done error' );
							status_el.children().first().attr( 'title','One or more requests failed being ' + action +'ed' );
						} else {
							status_el.addClass( 'done' );
							status_el.children().first().attr( 'title','Request(s) is/are done being ' + action +'ed' );
						}
						
						// Blind down group
						request_group_el.attr( 'orig_height', request_group_el.css('height') );
						
						if (!manually) {
							request_group_el.animate(
								{
									height: "0px"		
								},
								1000,
								function() {
																	
									// Move request group to bottom
									var container = request_group_el.parent();						
									
									var move_el = request_group_el.detach();						
									container.append( move_el );
									request_group_el.css( 'height', request_group_el.attr( 'orig_height' ) );
									
									// Check if all groups below app are done
									var app_groups = container.children();
									var not_done_groups = app_groups.find( '.status-icon:not(.group .status-icon.done,.group.template .status-icon)' );
									
									if ( not_done_groups.length == 0 ) {
										
										// If apps is done
										
										// Move app to bottom
										var app_el = container.parent();
										var app_container = app_el.parent();
										
										var move_el = app_el.detach();
										app_container.append( move_el );
										
									}
									if (callback) callback( request_el );
								}
							);
						} 
					} else {
						
						if (callback) callback( request_el );	
					}
				} else {
					
					if ( requestUniqueId == '101539264719_8936789' )
						console.log( '(4c)Should group for request with id ' + requestUniqueId + ' be marked as ' + state + '?' );
					if (callback) callback( request_el );					
				}
			
			} else {
				console.log( 'Could not find status el');
				if (callback) callback( request_el );
			}
		} else {
			console.log( 'Could not find request group' );
			if (callback) callback( request_el );
		}
	} else {
		console.log( 'Could not find request:' + request.getUniqueId() );
		if (callback) callback( false );
	}
}

function set_sound( sound_state ) {
	var snd_btn = $('#sound-toggle-btn');
	snd_btn.attr( 'class', 'item ' + sound_state );
	snd_btn.attr( 'title', 'Sound effects are ' + sound_state + '.' );
}

function _toggle_sound_click( evt ) {
	
	var snd_value;
	var snd_state;
	if ( $(this).hasClass( 'disabled' ) ) {
	
		// Enable sound
		snd_state = 'enabled';
		snd_value = '1';
		
	} else {
		
		// Disable sound
		snd_state = 'disabled';
		snd_value = '0';
	}
	
	// Save setting on account
	var account = bgp.current_login.account;
	account.sound = snd_value;
	
	// Show saving setting
	account.save( function( accounts ) {
		set_sound( snd_state );
		
		bgp.current_login.account = accounts[ 0 ];
		// Hide saving setting
	
	} );
	
}
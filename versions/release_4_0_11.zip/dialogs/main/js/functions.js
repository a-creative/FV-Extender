function unixTimestampToStr( unix_timestamp_sec ) {
						
	var js_timestamp_ms = unix_timestamp_sec * 1000;			//	milliseconds
	
	var timestamp = new Date( js_timestamp_ms );
	
	// Format date
	var yesterday = new Date();
	yesterday.setTime( yesterday.getTime() - 86400000 );
	yesterday.setSeconds(59);
	yesterday.setMinutes(59);
	yesterday.setHours(23);
	
	var before_yesterday = new Date();
	before_yesterday.setTime( yesterday.getTime() - 86400000 );
	
	var date_str = bgp.curr_transl.MONTHS[ timestamp.getMonth() ] + ' ' + timestamp.getDate();
	
	// Format time
	var l_time_str = timestamp.toLocaleTimeString();
	var time_str;
	var matches = l_time_str.match( /(\d{2}:\d{2}):\d{2}\s?(am|pm)?/i );						
	if ( matches ) {
		time_str = matches[ 1 ];
		if ( matches[ 2 ] ) {
			time_str += matches[ 2 ];
		}
	} else {
		time_str = l_time_str;
	}
	
	return ( date_str + ' - ' + time_str );
}

function FVE_alert( details ) {
	
	var wnd_options = {
		width: 500,
		height: 300
	};
		
	var content = $('<div />');
	
	content.append('<h1 style="color:red">Error</h1>');
		
	// Error description
		var description;
		
		if ( details.code == 'login_problems' ) {
			
			// HANDLED
			description = "Login problems are detected. Therefore requests are not updated.";
			wnd_options.height = 460;			
		} else if ( ( details.code == 'json_error' ) && ( details.target_data.indexOf( '/sorry.php?msg=account' ) == -1 ) && ( details.target_data != '' ) ) {
			
			// HANDLED
			description = "Couldn't extract requests from request list on Facebook. Therefore requests are not updated.";
			wnd_options.height = 460;
			
		} else if ( details.code == 'app_group_count_error' ) {
			
			// HANDLED
			description = "Couldn't find the expected apps/games. Therefore requests are not updated.";
			wnd_options.height = 440;
			
		} else if ( details.code == 'request_count_error' ) {
			
			// HANDLED
			description = "Couldn't find the expected requests from a certain app/game. Therefore requests are not updated.";
			wnd_options.height = 460;
			
		} else if ( details.code == 'request_loop_error' ) {
			
			// HANDLED
			description = "Unknown error related to loading requests. Therefore requests are not updated.";
			wnd_options.height = 460;
			
		} else if ( ( details.code == 'request_read_ajax_conn_err' ) || ( ( details.code == 'json_error' ) && ( ( details.target_data.indexOf( '/sorry.php?msg=account' ) != -1 ) || ( details.target_data == '' ) ) ) ) {
			
			// HANDLED
			description = "Couldn't connect to Facebook. Therefore requests are not updated.";
			wnd_options.height = 470;
			
		} else if ( details.code == 'db_error' ) {
			
			if ( details.err && details.err.code == '4' ) {
				
				// HANDLED
				description = "Internal database error related to disk space. Therefore requests are not updated.";
				wnd_options.height = 500;
				
			} else {
			
				wnd_options.height = 460;
			
				if ( details.err && details.err.message && details.err.message.indexOf( "unable to open a transaction" ) != -1 ) {
					description = "Internal database error. Therefore requests are not updated.(2)";
				} else {
					// HANDLED
					description = "Internal database error. Therefore requests are not updated.(1)";
				}
			}
			
		} else if ( details.code == 'wrong_db_object_err' ) {
			
			// HANDLED
			description = "Internal database error. Therefore requests are not updated.";
			wnd_options.height = 460;
			
		}
		
		// Add description
		if ( description ) {
			content.append('<p><b>Description:</b> ' + description + '</p>');
		}
		
	// Also try
			var also_try = '';
			if ( ( details.code == 'request_read_ajax_conn_err' ) || ( ( details.code == 'json_error' ) && ( ( details.target_data.indexOf( '/sorry.php?msg=account' ) != -1 ) || ( details.target_data == '' ) ) ) ) {
				also_try += '<li>Check if there are any problems with your internet connection.</li>';
				also_try += '<li>Facebook could be down. In that case try again later.</li>';
				also_try += '<li>Check if this page: <a href="http://www.facebook.com/games?ap=1">http://www.facebook.com/games?ap=1</a> shows your game requests. Try using FVE later if not.</li>';
			} else if( details.code == 'wrong_db_object_err' ) {
				also_try += '<li>No good solutions or work arounds. But:</li>';
				also_try += '<li>Try logging out of facebook then restart chrome and login again.</li>';
				
			} else if( details.code == 'login_problems' ) {
				also_try += '<li>Close FVE. Next open facebook. Log out of facebook and log in again. Finally open FVE again</li>';
				
			} else if ( details.code == 'db_error' ) {
				
				if ( details.err && details.err.code == '4' ) {
					also_try += '<li>No good solutions or work arounds. But try doing this:</li>';
					also_try += '1. Uninstall FV Extender<br />';
					also_try += '2. Restart Google Chrome<br />';
					also_try += '3. Install FV Extender again<br />';
					also_try += '4. Open FV Extender again<br />';
				} else {
					
					also_try += '<li>Close FVE and restart Google Chrome to recover from this.</li>';
				}				
			} else {
				also_try += '<li>No solutions or workarounds.</li>';
			} 
			
			if ( also_try ) {
				content.append( '<p><b>Possible solutions/workarounds:</b><ul>' + also_try + '</ul>' );
			}
		
	// What now(how to help)
		var what_now = 'Please copy the contents of the grey text '
					+	'area shown below into a text file and attach it to a new e-mail with the subject "FVE Error". ' 
					+	'Next send the e-mail to me at the address:</p><p> <a href="mailto:info.a.creative@gmail.com">info.a.creative@gmail.com</a></p><p>'
					+	'Sending this will help me understand what went wrong in your case and how to fix it.';	
		
		if ( what_now ) {
			content.append( '<p><b>If nothing helps or no good solutions or workarounds are listed:</b><p>' + what_now + '</p>' );
		}
	
	// Add data area
		var data_area = $('<textarea class="data-area" />');			
		var datas = [];
		var val;
		var target_data;
		for ( var key in details ) {
			val = details[ key ];
			if ( key == 'target_data' ) {
				target_data = val;	
			} else if ( ( typeof val ) === 'object' ) {
				for ( var key2 in val ) {
					
					if ( val[ key2 ] ) {
						datas.push( key2 + ':' + val[ key2 ] );
					}
				}				
				
			} else {
				if ( val ) {
					datas.push( key + ':' + val );
				}
			}
		}
		
		if ( navigator && navigator.userAgent ) {
			datas.push('User agent:' + navigator.userAgent );
		}
		
		if ( bgp.FVE_version ) {
			datas.unshift( 'FVE version:' + bgp.FVE_version );
		}
		
		if ( target_data ) {
			datas.push( 'Target data:\n' + target_data );
		}	
		data_area.text( datas.join( '\n*** data ***\n' ) );
		content.append( data_area );
		
		content.append('<p><a href="http://getsatisfaction.com/fv-extender/topics/how_do_i_send_you_an_errro_report" target="_blank">More on how to copy and send the text</a></p>')
			
		// Close button
		var close_btn = $('<a href="#" title="Close window" class="button" id="window-close-btn" onclick="hideWindow();return false" style="float:right">X Close window</a>' );
		
		content.append( close_btn )
		
	// Show window with content
	wnd_options.content = content.html();
	
	showWindow( wnd_options );
	
	
}
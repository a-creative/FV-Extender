if (typeof app_defs === 'undefined') { app_defs = {}; }

console.log('Loading app definition for FarmVille');

app_defs[ '102452128776' ] = {
    "name" : "FarmVille",
    "id" : "102452128776",
    "customer_support" : "fast", // vs. slow
    "accept_support" : "auto", // vs. manual
    "game_forum" : "http://forums.zynga.com/forumdisplay.php?f=91",
    "wiki" : "http://farmville.wikia.com/wiki/FarmVille_Wiki",
    "game_link" : "http://apps.facebook.com/onthefarm",
    "functions" : {
        "is_result_page" : function( tab_id, queue_tab_info, page_url ) {
            
            if ( page_url.indexOf( "gifts_send.php" ) !== -1 ) {
                return false;   
            } else {
                return true;
            }
        
        },
        "get_item_id" : function( request ) {
            
            var matches = FVE_http_decode( request.action_url ).match( /&gift=([^&]+)/ );
            if ( matches ) {
                return matches[ 1 ]
            } else {
                return undefined;
            }
        }, 
        "get_item_name" : function( request ) {
            
            if ( request.item_id == 'socialplumbingmysterygift' ) {
                return "Special Delivery";
            } else {
                
                var matches = request.text.match( /^Here is (?:a|an) (.+) for your farm/ );
                if ( matches ) {
                    return matches[ 1 ]
                } else {
                    
                    matches = request.text.match( /Here is a gift I received and want to share with you/ );
                    
                    if ( matches ) {
                        return request.item_id;
                    } else {
                        return undefined;
                    }
                }
            }
        },            
        
        // Decides whether to visually or silently accept a request
        /*
        "is_silent_accept" : function( request, app_def ) {
            
            if ( request.item_name ) {
                
                // Is gift request
                
                // Do visually
                return false;    
            } else {
                
                // Is help request
                
                // Do silently
                return true;
            }
            
        },
        */
        "is_help_request" : function( request, app_def ) {
            
            if ( request.item_name ) {
                
                // Is gift request
                
                return false;    
            } else {
                
                // Is help request
                
                return true;
            }
            
        },        
        // Process result page
        "processResultPage" : function( request, data, textStatus, XMLHttpRequest, app_url, callback ) {
            
            if ( app_url.indexOf( "request_ids=" ) != -1 ) {
                
                // If new request model
                
                // Find next page
                var matches = data.match( /goURI\('(.*)'\)/ );
                if ( matches.length ) {
                    
                    // If url for next page found
                    var url = matches[ 1 ];
                    var json = '{ "html" : "' + url + '" }';	
                    var obj = jQuery.parseJSON( json );							
                    url = obj.html.replace( /\\x26/g,'&');
                    
                    // Split url
                    var parts = url.split( "?" );
                    
                    // Request next page url
                    getData(
                        parts[ 0 ],
                        parts[ 1 ],
                        function( data, textStatus,jqXHR ) {
                        
                            // On success
                            request.state = 3;
                            request.state_text = 'Help request succesfully accepted';
                            
                            // Save updated state and callback
                            current_user_db.saveRequests( [ request ], callback );
                            
                        },
                        function( jqXHR, textStatus, errorThrown) {
                        
                            // On error
                            request.state = 6;
                            request.state_text = "Connection error";
                            
                            // Save updated state and callback
                            current_user_db.saveRequests( [ request ], callback );    
                            
                        }
                    );
                    
                } else {
                    request.state = 6;
                    request.state_text = "Couldn't find goURI tag";
                    
                    // Save updated state and callback
                    current_user_db.saveRequests( [ request ], callback );                       
                }
            } else {
            
                // If old request model
                
                // Just finish
                request.state = 3;
                request.state_text = 'Help request succesfully accepted';
                
                // Save updated state and callback
                current_user_db.saveRequests( [ request ], callback );
            }
            
            // (Return gift here)
            
        },
        "processResultPageVisualOnChange" : function( request_id, return_gift_text ) {
            
            // Detect and react to "angry cow" error
            var h1 = jQuery( 'h1' );
			if ( h1 && h1.length && h1.html().match( /Oh no/i ) ) {
				if_not_detected( h1, function( h1 ) {
					alert('oh no');
				
                	// Reload page
                } );
			}            
            
            // Detect and click on return gift button
			var return_gift_btn = jQuery( 'input[name=send]' );
			if ( return_gift_btn.length ) {
                console.log( 'Found gift back button');
                
				if ( return_gift_btn.val().match( /thank you/i ) ) {					
                    console.log( 'Found gift back button text ');
                	
                    if_not_detected( return_gift_btn, function( return_gift_btn ) {
						
                        console.log( 'Just before clicking the button.');
                	    
                        // If so click button to show return gift window
                        return_gift_btn.click();
					} );
				}
			}
            
            // Handle out of requests error
            
            // Detect text field for return gift message
            var msg_box = $('#personal_msg_box textarea');
			var send_return_gift_btn = jQuery( 'input[name=sendit]' );
			if ( ( send_return_gift_btn.length ) && ( msg_box.length) ) {
				if_not_detected( send_return_gift_btn, function( send_return_gift_btn ) {
					if_not_detected( msg_box, function( msg_box ) {
					    
                        // Return gift with message
                        msg_box.val( return_gift_text );
                        send_return_gift_btn.click();
					});
				});	
			}
        },
        "processResultPageVisualOnLoad" : function( app_id, request_id, FVE_is_help_request, callback ) {
            
            // Handle url only
                                
                var state;
                var state_text;
                
                // Handle errors
                console.log('Checking location:' + document.location.href );
                if ( document.location.href.match( /gifterror=notfound/ ) ) { state = 6; state_text = "Gift not found" };
                if ( document.location.href.match( /reqType=yes&clickSrc=$/ ) ) { state = 6; state_text = "Other error(1)" };
                if ( document.location.href.match( /toolbar\.zynga\.com/i ) ) { state = 6; state_text = "Other error(2)" };
                
                console.log('State after checking location:' + state);
                
                // Process help requests as accepted (leave room for exceptions in the future)
                if ( FVE_is_help_request && ( !state ) ) {
                    state = 3;
                    state_text = "Help request successfully accepted"
                };
                
                if ( state ) {
                    
                    // Finish
                    finish_request( app_id, request_id, state, state_text, function() {
                        
                        console.log( "Finishing!" );
                        
                        // And ignore onChange handling by returning true for handled
                        callback( true );
                    } );
                    
                    console.log("Return on url handled" );
                    return;
                }
            
            // Handle html only
            
                console.log('Checking html');
                var html_el = extractFacebookPagelets( $(document.body).html() );            
                
                if ( html_el ) {
                   
                    // Handle gift returned page and gift received page
                    var yes_el = html_el.find('input[value="Yes"]');
                    var send_btn_el = html_el.find('input[name="send"]');                
                    
                    if (
                            ( yes_el && yes_el.length )
                        &&  ( (!send_btn_el) || ( send_btn_el && send_btn_el.length == 0 ) )
                    ) {
                        // If "Yes" button found but not "Send" button
                        
                        console.log('Yes button found');
                        
                        // Finish
                        finish_request( app_id, request_id, 3, "Gift succesfully accepted", function() {
                            
                            console.log('Request finished succesfully');
                            
                            // And ignore onChange handling by returning true for handled
                            callback( true );    
                        } );
                        
                        
                    } else {
                        
                        console.log( "Letting onchange check it" );
                        callback( false );
                    }
                } else {
                    
                    finish_request( app_id, request_id, 6, "Gift failed due to no page content", function() {
                        
                        // And ignore onChange handling by returning true for handled
                        callback( true );    
                    });
                }
                
        },
        "checkForHang" : function() {
            console.log( "Check for hang injection" );
            
            // Detect and click on return gift button
			var return_gift_btn = jQuery( 'input[name=send]' );
			if ( return_gift_btn && return_gift_btn.length ) {
                console.log( 'Found gift back button');
                
				if ( return_gift_btn.val().match( /thank you/i ) ) {					
                    console.log('Clicked gift back button');                    
                    
                    // If so click button to show return gift window
                    return_gift_btn.click();
                    
				} else {
                    console.log('(1)Didn\'t find gift back button');       
                }
			} else {
                console.log('(1)Didn\'t find gift back button');       
            }
        }
    }
};

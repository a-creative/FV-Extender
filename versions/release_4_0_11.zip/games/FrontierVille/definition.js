if (typeof app_defs === 'undefined') { app_defs = {}; }

console.log('Loading app definition for FrontierVille');

app_defs[ '201278444497' ] = {
    "name" : "FrontierVille",
    "id" : "201278444497",
    "customer_support" : "slow", // vs. slow
    "accept_support" : "auto", // vs. manual
    "game_forum" : "",
    "FVE_support" : "",
    "wiki" : "",
    "game_link" : "http://apps.facebook.com/frontierville",
    "functions" : {
        "get_item_id" : function( request ) {
			
			var action_url =  FVE_http_decode( request.action_url );
			
			var matches = action_url.match( /&gift=([^&]+)/ );
            if ( matches ) {
				return matches[ 1 ]
            } else {
                return undefined;
            }
        },
        "get_item_name" : function( request ) {
            
			if ( request.item_id == 'gift_mystery2' ) {
                return "Mystery Gift";
            } else {
				
				var matches = request.text.match( /^Thank you for sending me (?:a\s)?(.+?)\!  Here is one back/ );
				if ( matches ) {
					return matches[ 1 ]
				} else {
					
					matches = request.text.match( /^Thank you for sending me (?:a\s)?.+?\. Here's (?:a\s)?(.+?) for/ );
					if ( matches ) {
						return matches[ 1 ]	
						return matches[ 1 ];
					} else {
						matches = request.text.match( /^Here's a (.+) for your homestead/ );
						if ( matches ) {
							return matches[ 1 ]	
						} else {
							return undefined;
						}
					}
				}
            }
        },
        
        // Decides whether to visually or silently accept a request
        "is_silent_accept" : function( request, app_def ) {
            
            return true;
            
        },
        
        // Process result page
        "processResultPage" : function( request, data, textStatus, XMLHttpRequest, app_url, callback ) {
            
			var html_el = extractFacebookPagelets( data );
			
			// Find form for iframe data
			var iframe_form = html_el.find( 'form[target=iframe_canvas]');
			if ( iframe_form.length ) {
				
				// Find form data
				var url = iframe_form.attr( 'action' );
				var form_data = iframe_form.serialize();
				
				// Request app result page
				postData( url, form_data,
					function( data, textStatus,jqXHR ) {
						
						// On success
						app_defs[ request.app_id ].functions.processAppResultPage( request, data, textStatus, XMLHttpRequest, callback );
					},
					function( jqXHR, textStatus, errorThrown) {
						
						// On error
						request.state = 6;
						request.state_text = textStatus;
						
						// Save updated state and callback
						current_user_db.saveRequests( [ request ], callback );		
					}
				);
				
			} else {
				// On error
				request.state = 6;
				request.state_text = "Could not find iframe to request";
				
				// Save updated state and callback
				current_user_db.saveRequests( [ request ], callback );			
			}
		},
		"processAppResultPage" : function ( request, data, textStatus, XMLHttpRequest, callback ) {
			request.state = 3;
            request.state_text = 'Request succesfully accepted';
            
            // Save updated state and callback
            current_user_db.saveRequests( [ request ], callback );	
		}
    }
};

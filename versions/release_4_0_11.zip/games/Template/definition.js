/*
app_defs[ '102452128776' ] = {
    "name" : "FarmVille",
    "id" : "102452128776",
    "support" : "FULL", 
};
*/
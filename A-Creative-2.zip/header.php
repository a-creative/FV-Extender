<!DOCTYPE html>
<html>
	<head>
		<title>FV Extender <?php wp_title ( '| ', true,'left' ); ?></title>

		<!-- meta information -->
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		
		<!-- force IE to use the best renderer -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

		<!-- Assign favorite icon -->
		<link rel="shortcut icon" href="<?php bloginfo( 'template_url' ); ?>/favicon.ico">
		
		<!-- Load CSS -->
		
		<!--- Reset browser defaults -->
		<link rel="stylesheet" href="<?php bloginfo( 'template_url' ); ?>/css/reset.css">
		
		<!-- Main style sheet -->
		<link rel="stylesheet" type="text/css" href="<?php bloginfo( 'stylesheet_url' ); ?>">
		
		<!-- Menu style sheet -->
		<link rel="stylesheet" type="text/css" href="<?php bloginfo( 'template_url' ); ?>/css/menu.css">
		
		<!-- Print style sheet -->
		<link rel="stylesheet" type="text/css" media="print" href="<?php bloginfo( 'template_url' ); ?>/css/print.css">
			
		<!-- Alternate views -->
		<link rel="alternate feed" type="application/rss+xml"  href="<?php bloginfo( 'rss2_url' ) ?>" title="FV Extender RSS feed">
		<link rel="alternate feed" type="application/atom+xml"  href="<?php bloginfo( 'atom_url' ) ?>" title="FV Extender Atom feed">
		
		<!-- WP pingback -->
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
			
		<!-- Load JS -->
		
		<?php
			/*
			 *  Add this to support sites with sites with threaded comments enabled.
			 */
			if ( is_singular() && get_option( 'thread_comments' ) )
				wp_enqueue_script( 'comment-reply' );
		 
			wp_head();
		 
			wp_get_archives('type=monthly&format=link');
		?>	
		
		<!-- Load JQuery from Google with fallback -->
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js"></script>
		<script>!window.jQuery && document.write('<script src="<?php bloginfo( 'template_url' ); ?>/js/jquery-1.6.3.min.js"><\/script>')</script>
		
		<?php custom_src() ?>
	</head>
	<body>
		<div class="site">
			 <header class="top">
				<?php
					if(function_exists('show_media_header')){
						show_media_header();
					} else { ?>
						<a href="<?php echo get_option('home'); ?>" title="Home"><img src="<?php bloginfo( 'template_url' ); ?>/gfx/logo.jpg" alt="FV Extender logo" /></a>
					<?php }
				
				?>
				<nav>
					<?php
						$menu = wp_nav_menu( array( 'sort_column' => 'menu_order', 'menu_class' => 'main-nav', 'theme_location' => 'primary-menu', 'echo' => '0' ) );
						$menu = str_replace( "Home", "Blog", $menu ) ; 
						echo $menu; // echo modified menu
					 ?>
				</nav>			
			</header>
			
			

<?php
 
 
 
 
//Add support for WordPress 3.0's custom menus
add_action( 'init', 'register_my_menu' );
 
//Register area for custom menu
function register_my_menu() {
    register_nav_menu( 'primary-menu', __( 'Primary Menu' ) );
}

// Remove title attribute from menu
function my_menu_notitle( $menu ){
  return $menu = preg_replace('/ title=\"(.*?)\"/', '', $menu );

}
add_filter( 'wp_nav_menu', 'my_menu_notitle' );
add_filter( 'wp_page_menu', 'my_menu_notitle' );
add_filter( 'wp_list_categories', 'my_menu_notitle' );





//Some simple code for our widget-enabled sidebar
if ( function_exists('register_sidebar') )
    register_sidebar(); 
 
add_theme_support('post-thumbnails');
set_post_thumbnail_size(520, 250, true);

function home_page_menu_args( $args ) {
	$args['show_home'] = true;
	return $args;
}
add_filter( 'wp_page_menu_args', 'home_page_menu_args' ); 

function the_breadcrumb() {
	if (is_home()) {
		echo the_title();
	} else {
		
		
		
		
		echo '<a href="';
		echo get_option('home');
		echo '">';
		bloginfo('name');
		echo "</a> » ";
		if (is_category() || is_single()) {
			the_category('title_li=');
			if (is_single()) {
				echo " » ";
				the_title();
			}
		} elseif (is_page()) {
			echo the_title();
		}
	}
}
 
function my_get_category_links() {
	
	$text = '';
	
	if (is_category()) {
		$text = 'Archive for the &#8216;' . single_cat_title() . '&#8217; Category:';
	} elseif( is_tag() ) { 
		$text = 'Posts Tagged &#8216;' . single_tag_title() . '&#8217;';	
	} elseif (is_day()) { 
		$text = 'Archive for ' . the_time('F jS, Y'). ':';
	} elseif (is_month()) { 
		$text = 'Archive for ' . the_time('F, Y') . ':';
	} elseif (is_year()) {
		$text = 'Archive for ' . the_time('Y') . ':';
	} elseif (is_author()) { 
		$text = 'Author Archive';
    } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) {
		$text = 'log Archives';
	}
	
	return '<h2>' + $text + '</h2>';
}

function get_page_content( $type ) {
	
	// Add header
	echo get_header();
	
	// Start content
	echo '<section class="content">';
	
	// Start main column
	echo '<section class="posts column">';
	
	if(have_posts()) :
		
		$count = 0;
		
		// Add posts
		while(have_posts()) : the_post();
			
			$count ++;

			if ( $type == 'category' ) {
				
				$post = $posts[0]; // Hack. Set $post so that the_date() works.
				echo my_get_category_links();
				
			}

			// Add post with anchor
			echo '<article class="post" id="' . get_the_ID() . '">';
			
			// Start post header
			echo '<header>';
			
			// Add time
			echo '<time pubdate datetime="' . get_the_modified_date('c') . '">' . get_the_modified_date('F j, Y - g:i a T') . '</time>';
			
			// Add post headline			
			echo '<h1>';
			
			if ( is_home() ) {
				the_title();
			} else {
				
				$ancestors = get_ancestors( get_the_ID(), 'page' );
				
				$path = '';
				
				foreach ( $ancestors as $page_id ) {
					
					$page = get_page( $page_id );
				
					$path .= $page->post_title;
				}
				
				
				
				if ( $path != '' ) {
					echo $path . ' / ';
				}
				
				echo get_the_title();
			}		
			
			echo '</h1>';
			
			// End post header
			echo '</header>';		
			
			// Start post entry
			echo '<section class="entry">';
			
			// Add post thumbnail
			if ( $type == 'single' || $type == 'index' ) {
				the_post_thumbnail();
			}
			
			// Add post content
			$content = get_the_content();
			$content = apply_filters('the_content', $content);
			$content = str_replace(']]>', ']]&gt;', $content);
			$content = str_replace('[[UNIX_TIMESTAMP]]', time(), $content );
			
			echo $content;
			
			
			
			// Add commenting
			/*
			echo '<br /><br />';
			comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;') . edit_post_link('Edit', ' &#124; ', '');
			*/
			
			
			
			// End entry
			echo '</section>';
			
			/*
			if ( $type == "single" || $type == "category" ) {
				
				echo '<div class="comments-template">';
				comments_template();
				echo '</div>';				
			}
			*/
			
			// End post
			echo '</article>';
	 
		endwhile;
		// Finished adding posts
	 
		if ( $count > 1 ) {
	 
			// Add posts navigation
			echo '<nav>';
			posts_nav_link( ' ' );
			echo '</nav>';
		}
		
	endif;
	
	// End main column footer
	echo '<footer class="main-column-footer"></footer>';
	
	// End main column
	echo '</section>';
	
	// Start side bar
	echo '<aside class="column">';
	
	// Add sidebar content
	get_sidebar();
	
	// End side bar
	echo '</aside>';
	
	// Content footer
	echo '<footer class="content-footer"></footer>';
	
	// End content
	echo '</section>';
		
	// Add footer
	get_footer();
}

function custom_src() {
	
	$id = get_the_ID();
	$css_docs = get_post_meta($id, 'custom_css', false);
	$js_docs = get_post_meta($id, 'custom_js', false);
	
	$has_css = !empty( $css_docs );
	$has_js = !empty( $js_docs );
	
	$template_url = get_bloginfo( 'template_url' );
	
	if ( $has_css ) {
		
		echo '<!--Custom CSS for ' . get_the_title() . '.-->' . "\n";
		foreach ($css_docs as $css) {
			echo '<link rel="stylesheet" href="'. $template_url . $css.'" type="text/css">'."\n";
		}
	}
	
	if ( $has_js ) {
		
		echo '<!--Custom JS for ' . get_the_title() . '.-->' . "\n";
		
		echo "<script>var wp_template_url = '" . $template_url . "';</script>";
		
		foreach ( $js_docs as $js ) {
			echo '<script src="' . $template_url . $js .'"></script>'."\n";
		}
	}
	
}


 
 
?>
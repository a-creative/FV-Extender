<ul>	
	<li>
	  <h1>Recommend FV Extender:</h1>
	  <!-- Place this tag where you want the +1 button to render -->
	  <div class="g-plusone" data-annotation="inline" data-width="180" data-href="http://www.facebook.com/pages/FV-Extender/193543664006872"></div>
	  <!-- Place this render call where appropriate -->
	  <script type="text/javascript">
		(function() {
		  var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
		  po.src = 'https://apis.google.com/js/plusone.js';
		  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
		})();
	  </script>
	  <br /><br /><br /> 
	  <div id="fb-root"></div>
	  <script>(function(d){
		var js, id = 'facebook-jssdk'; if (d.getElementById(id)) {return;}
		js = d.createElement('script'); js.id = id; js.async = true;
		js.src = "//connect.facebook.net/en_US/all.js#appId=214438501949707&xfbml=1";
		d.getElementsByTagName('head')[0].appendChild(js);
	  }(document));</script>
	  <div class="fb-like" data-href="http://www.facebook.com/pages/FV-Extender/193543664006872" data-send="false" data-width="180" data-show-faces="true"></div>
	</li>
	<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar() ) : else : ?> 
	<?php endif; ?>
</ul>
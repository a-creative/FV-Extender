$(document).ready( function() {

	$('.cp-link').click( function( evt ) {
		
		anim_init();
		evt.preventDefault();
	});

} );



// Animation variables
var ghosty_def;
var beam_def;
var cp_main_wnd;
var canvas_el;
var ctx;
var beam_wait;
var stop_at;
var stop_reached;
var beam;
var cp_window_opacity;
var anim_interval;
var fps = 30;
var focus_changed;
var beam_audio_src;
var ghosty_audio_src;

function addAudioClip( audio_source, audio_clip_path ) {  
	$('<source>').attr('src', audio_clip_path ).appendTo( audio_source );  
} 

function anim_init() {
	
	focus_changed = false;
	
	// Dimensions of ghosty sprite
	ghosty_def = {
		width: 200,
		height: 159,
		frame_count: 6,
		current_frame_no: 1,
		frames: [],
		x : 0,
		speed: 6,
		current_speed: 0
	};
	
	ghosty_def.current_speed = ghosty_def.speed;
	
	// Dimensions of beam sprite
	beam_def = {
		width: 488,
		height : 194,
		frame_count: 4,
		current_frame_no: 1,
		frames: [],
		x: 0
	};
	
	// Create main window to show when ghosties is "beaming it down"
	cp_main_wnd = $('<div id="cp-window" />');
	cp_main_wnd.html( '<p><a href="http://google.dk" target="_blank">Go</a></p>');
	$(".site > .content > .posts").append( cp_main_wnd );
	
	
	
	// Create canvas for sprite animation
	canvas_el = document.createElement('canvas');
	canvas_el.id = 'anim-canvas';
	
	// Set dimension of canvas to width of window and the combined height of the ghosty and beam sprites
	canvas_el.width = $(window).width();
	canvas_el.height = ghosty_def.height + beam_def.height;
	
	// Insert canvas into DOM
	document.body.appendChild( canvas_el );
	
	// Get canvas 2D context
	ctx = canvas_el.getContext( '2d' );
	
	// Number of frames
	beam_wait = 1;
	
	// Set starting position of sprite
	ghosty_def.x = canvas_el.width;
		
	// Calculate where to stop
	stop_at = ( canvas_el.width / 2 ) - ( ghosty_def.width / 2 );
	stop_reached = false;
	
	// Beam status
	beam = false;
	cp_window_opacity = 0;
	
	
	// Load audio source for ghosty sound
	/*
	ghosty_audio_src = $('<audio id="ghosty-audio-src" />', { loop: true, preload: "auto", autobuffer : "autobuffer" } );
	addAudioClip( ghosty_audio_src, wp_template_url + "/career_portfolio/snd/ghosty.mp3");
	addAudioClip( ghosty_audio_src, wp_template_url + "/career_portfolio/snd/ghosty.ogg");
	$(document.body).append( ghosty_audio_src );
	*/
	
	ghosty_audio_src = $('<div id="ghosty-audio-src" />').appendTo( $(document.body) );
	ghosty_audio_src.jPlayer( {
		ready: function () {
			$(this).jPlayer(
				"setMedia",
				{
					mp3: wp_template_url + "/career_portfolio/snd/ghosty.mp3",
					ogg: wp_template_url + "/career_portfolio/snd/ghosty.ogg"
				}
			);
			
			$(this).jPlayer("play");
			
		},
		swfPath: wp_template_url + "/js",
		supplied: "mp3, ogg",
		solution:"flash, html",
		loop: true,
		preload: "auto",
		volume: 0.8
	} );
	$(document.body).append( ghosty_audio_src );	
	
	
	// Start animation
	anim_interval = setInterval( animate, ( 1000 / fps ) );	
	
	// Preload beam sprite
	for ( var i = 1; i <= beam_def.frame_count ; i++ ) {
		beam_frame = new Image();
		beam_frame.src  = wp_template_url + "/career_portfolio/gfx/beam_sprite/beam_" + i + ".png";
		
		beam_def.frames.push( beam_frame );		
	}
	
	// Load audio source for beam down sound
	beam_audio_src = $('<div id="beam-audio-src" />');
	$(document.body).append( beam_audio_src );	
	beam_audio_src.jPlayer( {
		ready: function () {
			$(this).jPlayer(
				"setMedia",
				{
					mp3: wp_template_url + "/career_portfolio/snd/beam_down.mp3",
					ogg: wp_template_url + "/career_portfolio/snd/beam_down.ogg"
				}
			);
			
		},
		swfPath: wp_template_url + "/js",
		supplied: "mp3, ogg",
		solution:"flash, html",
		loop: true,
		preload: "auto",
		volume: 0.8
	} );
	
	
	
	
	
	
	
}

function animate() {
	draw();
	model();
}

function draw() {
	
	if ( beam ) {
		
		if ( !beam_def.x ) {
			beam_def.x = ( ghosty_def.x + ( ghosty_def.width / 2 ) ) - ( beam_def.width / 2 );
		}
		
		// Draw beam
		ctx.clearRect( beam_def.x, ghosty_def.height, beam_def.width, beam_def.height );
		ctx.drawImage( beam_def.frames[ beam_def.current_frame_no - 1 ], beam_def.x, ghosty_def.height );
	}	
	
	// Draw ghosty sprite		
	if ( ghosty_def.frames[ ghosty_def.current_frame_no ] ) {
		
		// Get sprite from memory
		// Clear last fame
		ctx.clearRect( ghosty_def.x + ghosty_def.current_speed + 50,0, ghosty_def.width, ghosty_def.height );		
		
		// Draw new frame
		ctx.drawImage( ghosty_def.frames[ ghosty_def.current_frame_no ], ghosty_def.x, 0);	
	} else {
	
		// Load sprite
		var frame = new Image();
		frame.onload = function() {
			
			// Clear last fame
			ctx.clearRect( ghosty_def.x + ghosty_def.current_speed + 50,0, this.width, this.height );
			
			// Draw new frame
			ctx.drawImage( this, ghosty_def.x, 0);		
		}
		frame.src = wp_template_url + "/career_portfolio/gfx/ghosty_sprite/ghosty_" + ghosty_def.current_frame_no + ".png";
		ghosty_def.frames[ ghosty_def.current_frame_no ] = frame;
	}	
}

function model() {
	
	// Set current frame no for beam
	if ( beam ) {
		
		beam_wait++;
		if ( beam_wait > 5 ) {
			
			// Change image after every 5 frames
			beam_def.current_frame_no++;
			if ( beam_def.current_frame_no > beam_def.frame_count ) {
				beam_def.current_frame_no = 1;
			}
			
			if ( beam_def.current_frame_no == beam_def.frame_count ) {
				cp_window_opacity += 0.25;
				$('#cp-window').css( 'opacity', cp_window_opacity );
				
				if ( cp_window_opacity > 1 ) {
					var pos_x = ( ghosty_def.x + ( ghosty_def.width / 2 ) ) - ( beam_def.width / 2 );
					
					ctx.clearRect( pos_x, ghosty_def.height, beam_def.width, beam_def.height );						
					beam = false;
					ghosty_def.current_speed = ghosty_def.speed;
					beam_audio_src.jPlayer( "stop" );
					ghosty_audio_src.jPlayer("play");
				}
			}
			
			beam_wait = 1;
		}
	}
	
	// Set current frame no for Ghosty
	ghosty_def.current_frame_no ++;
	if ( ghosty_def.current_frame_no > ghosty_def.frame_count ) {
		ghosty_def.current_frame_no = 1;
	}
	
	if ( (!stop_reached) && ( ghosty_def.x < stop_at ) ) {
		
		// Stop when reaching middle of page			
		stop_reached = true;
		ghosty_def.current_speed = 0;
		
		ghosty_audio_src.jPlayer( "stop" );
		beam_audio_src.jPlayer( "play" );
		beam = true;
	}
	
	// Change position
	ghosty_def.x -= ghosty_def.current_speed;
	
	if ( ( !focus_changed) && ghosty_def.x < ( stop_at - 500 ) ) {
		focus_changed = true;
		$('#anim-canvas').css('z-index', 1 );
		$('#cp-window').css('z-index', 2 );
	}
	
	
	if (  ghosty_def.x < - ghosty_def.width ) {
		
		$('#anim-canvas').remove();
		ghosty_audio_src.jPlayer("pause");
		
		// Stop animation when ghosty has left the view
		clearInterval( anim_interval );
	}
	
}

